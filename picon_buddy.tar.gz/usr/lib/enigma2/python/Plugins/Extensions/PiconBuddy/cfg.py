##############################################################################
#	(c)2022 by Oberhesse (contact through www.vuplus-support.org)
#	Creative Commons CC BY-NC-SA 3.0 License
#	Check the file "LICENSE" for more informations
# 	Images by NaseDC
##############################################################################
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Components.config import config, ConfigSubsection, getConfigListEntry, ConfigText, ConfigYesNo, ConfigInteger, ConfigSelection
from Components.ConfigList import ConfigListScreen
from Screens.ChoiceBox import ChoiceBox
from Components.Label import Label
from enigma import getDesktop, eLabel, eTimer
import skin, os, datetime
from .__init__ import _

logMode = -1
scale = getDesktop(0).size().width()/1280.0  
def scaled(i): return int (round(i*scale))

PATH="/usr/lib/enigma2/python/Plugins/Extensions/PiconBuddy/"

def readDebug ():
	try:
		if not os.path.exists( PATH +'debug.txt'):  return []
		with open(PATH +'debug.txt') as file:  return file.readlines()
	except: return []
	

def debug(s, flag='a', fName='debug.txt', minMode=1): 
	try: 
		if debugMode() < minMode:  return 0
		_time = datetime.datetime.now().strftime("%H:%M:%S [%f]")[:12]+']:  '
		if (minMode==1) and (fName=='debug.txt') and (flag!='w'):  #1=debug 2=Log
			_lines = readDebug()
			s =  _time + str(s);  sum = 0
			for  _line in _lines: 
				if  _line.strip(): s += '\n' + _line.strip();  sum += 1
				if sum>=100 : break
			flag = 'w'
		else: s = ['',_time][minMode==2] + str(s).strip() + '\n'
		f = open( PATH+fName , flag);  f.write( s );  f.close()
	except: pass
	

def debugMode( reset = 0): 
	global logMode
	if reset or (logMode<0):  logMode = getInt(config.plugins.PiconBuddy.log.value)
	return logMode
	
	
def scaledSkin (skin):
	def scaleVal(s):
		try: return scaled(int(s)) 
		except: return 0	
	def sPos (s, text): i = text.find(s);   return [ i, 999999 ][ (i<0) or (s=='') ] 
	def firstElemInText ( elem1, elem2, elem3, text ):
		i = min( sPos(elem1, text), sPos(elem2, text), sPos(elem3, text) )
		return [ i, -1 ][ i==999999 ]
	res = ''
	while len(skin):
		i = firstElemInText ( '"_' , ',_', ';_' , skin )
		if (i<0): return res + skin
		res += skin [ :(i+1)];  skin = skin [ (i+2): ];  i = firstElemInText (  '"' , ',' , '', skin )
		if i < 0: return res + skin
		res += str( scaleVal(skin[ :i ]));  skin = skin [ i: ]
	return res + skin

pathList = []
	
def getPathList ( init=0):
	def add (fName):
		try:
			global pathList
			if os.path.isdir(fName): 
				pathList.append ( [fName,fName] )
				if not init:
					bak = fName + '/bak'
					if os.path.exists(bak) and os.path.isdir(bak):  pathList.append ( [bak,bak] )
		except: pass
	global pathList;  pathList = [];   dir0 = dir1 = ''
	try:  dir0 =getattr(config.usage, 'picon_dir').value
	except: dir0 = ''
	try:  dir1 =getattr(config.usage, 'servicelist_picon_dir').value
	except: dir1 = ''
	try:
		if dir0 == None: dir0 = ''
		if dir1 == None: dir1 = ''
		if dir0 == dir1:  dir1 =''
		dir0, dir1 = dir0.rstrip('/'), dir1.rstrip('/')
		if dir0 and os.path.exists(dir0) and os.path.isdir(dir0): add( dir0 )
		if dir1 and os.path.exists(dir1) and os.path.isdir(dir1): add(dir1)
	except Exception as e:  debug(e,'a');  dir0 = dir1 = ''
	try:
		for p in  ['/usr/share/enigma2', '/media/usb', '/media/hdd', '', '/media/cf', '/media/mmc1' ]:
			if (p=='') or (os.path.exists(p) and os.path.isdir(p)):
				for f in os.listdir( [ p, '/' ][ p=='' ] ):
					pPath = p + '/'+ str(f)
					if (pPath==dir0) or (pPath==dir1): continue
					if str(f).lower().startswith('picon'):  add ( pPath )
	except: pass
	if not init:  
		pathList.append( ['ohne',''] )
	else: 
		if len(pathList)==0: pathList.append ( [ '/usr/share/enigma2/picon', '/usr/share/enigma2/picon' ] )
		while len(pathList)<5: pathList.append( ['',''] )
	return pathList
	
try: getPathList(1)
except: pathList = [  ['/usr/share/enigma2/picon', '/usr/share/enigma2/picon'], ['',''] ]

def isDir( s):
	s = s.rstrip('/')
	return (s!='') and os.path.exists(s) and os.path.isdir(s)
	
def getInt (s):
	try:  
		if not s.strip(): return 0
		return int(str(s).strip())
	except: return 0
	
config.plugins.PiconBuddy = ConfigSubsection()
config.plugins.PiconBuddy.path1 = ConfigText(default= pathList[0][1] )
config.plugins.PiconBuddy.path2 = ConfigText(default= pathList[1][1] )
config.plugins.PiconBuddy.path3 = ConfigText(default='')
config.plugins.PiconBuddy.path4 = ConfigText(default='')
config.plugins.PiconBuddy.path5 = ConfigText(default='')
config.plugins.PiconBuddy.wide = ConfigYesNo(default=False)
config.plugins.PiconBuddy.compact = ConfigYesNo(default=True)
config.plugins.PiconBuddy.html = ConfigYesNo(default=False)
config.plugins.PiconBuddy.fontScale = ConfigInteger(default=100, limits = (50, 150))
config.plugins.PiconBuddy.yDif = ConfigInteger(default=5, limits = (0, 10))
config.plugins.PiconBuddy.lastPath = ConfigInteger(default=1)
config.plugins.PiconBuddy.log =  ConfigSelection(default = '2',  
	choices =  [ ("0",_("No Logfiles")),  ("1",_("Error Debug File [debug.txt]")), ("2",_("Debug and Logfile [debug.txt, picons.txt]")) ])  
config.plugins.PiconBuddy.syntax =  ConfigSelection(default = '0',  
	choices =  [ ("0",_("VTi")),  ("1",_("Extended (Interoperable)")) ])  

			
def getCfgVal(id):
	try:  return getattr( config.plugins.PiconBuddy, id).value
	except: return 0

def getNewPath (nr):
	res = ''
	try:
		if (nr>=1) and (nr<=5):
			res = getattr( config.plugins.PiconBuddy, 'path'+str(nr)).value
			if res and  ( (res=='/') or isDir(res) ):
				config.plugins.PiconBuddy.lastPath.value = nr;  config.plugins.PiconBuddy.lastPath.save()
				return res.rstrip('/') + '/'
	except Exception as e: debug( e, 'a')
	return ''
	
def getActPath():
	idx = config.plugins.PiconBuddy.lastPath.value
	res = getNewPath( idx)
	if (res=='') or (not os.path.exists(res)) or (not os.path.isdir(res)):  return '/usr/share/enigma2/picon'
	return res
	
def getOtherPathes( actPath='' ):
	res = [];  actPath = actPath.rstrip('/')
	for i in range(1,6):
		path = getattr(config.plugins.PiconBuddy, 'path'+str(i)).value.rstrip('/')
		if (path != actPath) and isDir(path) and not (path in res): 
			res.append(path)
			bak= path + '/bak'
			if not (bak in res):  res.append(bak)
	return res
	
	
def isWide():  return config.plugins.PiconBuddy.wide.value==True
def isCompact():  return config.plugins.PiconBuddy.compact.value==True
def htmlStat():  return config.plugins.PiconBuddy.html.value==True
def fontScale():  return config.plugins.PiconBuddy.fontScale.value
def isInteroperable(): return (config.plugins.PiconBuddy.syntax.value == "1")
def yDif():  return config.plugins.PiconBuddy.yDif.value



class menu (Screen, ConfigListScreen):
	skin = """<screen position="center,center" size="_820,_515" title="Picon Buddy Einstellungen" >
		<widget name="config" font="Regular;_24"  position="_20,_25" size="_780,_440" itemHeight="_36" />
		<eLabel backgroundColor="#aa0000" position="_20,_480" size="_10,_35" />
		<widget name = "info_red"  foregroundColor="#dddddd" position="_45,_480" size="_250,_35"  font="Regular;_21"  
			valign="top" transparent="1" zPosition="10"   />
		<eLabel backgroundColor="#00aa00" position="_280,_480" size="_10,_37" />
		<widget name = "info_green"  foregroundColor="#dddddd" position="_305,_480" size="_250,_37"  font="Regular;_21"  
			valign="top" transparent="1" zPosition="10"   />
		</screen>""" 

	def __init__(self, session, args = 0):
		self.session = session
		Screen.__init__(self, session)
		self.list = []
		self.pathList = getPathList()
		ConfigListScreen.__init__(self, self.list, session = self.session) #on_change = self.onChanged
		for i in range(1,6):   
			self.list.append( getConfigListEntry ( _('Picon Path')+' '+str(i),  getattr( config.plugins.PiconBuddy, 'path'+str(i)) ))
		self.list.append( getConfigListEntry (_('Primary By-Name-Syntax'),  config.plugins.PiconBuddy.syntax) )
		self.list.append( getConfigListEntry (_("Compact Mode"),  config.plugins.PiconBuddy.compact) )
		self.list.append( getConfigListEntry (_("Wide Picons"),  config.plugins.PiconBuddy.wide) )
		self.list.append( getConfigListEntry (_("Font Scale (%)"),  config.plugins.PiconBuddy.fontScale) )
		self.list.append( getConfigListEntry (_("Vertical Margin (0..10)"),config.plugins.PiconBuddy.yDif) )
		self.list.append( getConfigListEntry (_("Logfiles"),  config.plugins.PiconBuddy.log) )
		self.list.append( getConfigListEntry (_("Create HTML File [picons.html]"),  config.plugins.PiconBuddy.html) )
		self["actions"] = ActionMap(  ["OkCancelActions","ColorActions"], { "cancel": self.exit, "red":self.setPath, "green":self.save}, -1)
		self["info_red"] = Label(_('Choose Picon Path'))
		self["info_green"] = Label(_(''))
		self["config"].onSelectionChanged.append(self.setLabel)
		self.skin = scaledSkin(self.skin)
		debugMode(1)
		self.onClose.append(self.doClose)
		self.onLayoutFinish.append(self.init)
		self.stateTimer = eTimer();  self.stateTimer.callback.append(self.checkState);  self.stateTimer.start(1000)
		
	def init (self):  self["config"].instance.setWrapAround(True); #self["info_red"].setText('xxxx')
	
	def setLabel(self):    
		self["info_red"].setText(  [ '', _('Choose Picon Path')][ self["config"].getCurrentIndex()<=4] )
		self["info_green"].setText ( [ '', _('Save') ][self["config"].isChanged()] )
		
	def checkState(self):
		try:
			self.stateTimer.stop()
			self.setLabel()
			self.stateTimer.start(1000)
		except: pass
		
	def callBack(self, answer): 
		try:
			if answer == None: return 0
			path = answer[1]
			idx = self["config"].getCurrentIndex() +1
			if (idx>=1) and (idx<=5):  getattr( config.plugins.PiconBuddy, 'path'+str(idx)).value = path
		except Exception as e:  debug(e, 'a')
	
	def setPath(self):
		if self["config"].getCurrentIndex()<=4:
			self.session.openWithCallback( self.callBack, ChoiceBox, title=_("Choose Picon Path"),  list=getPathList()  )
		self.setLabel()
	
	def save(self):
		self.saveAll()
		self.setLabel()
		debugMode(1)
			
	def doClose(self):  
		debugMode(1)
		self.stateTimer.stop()

	def exit(self):
		self.keyCancel()



			
		
		