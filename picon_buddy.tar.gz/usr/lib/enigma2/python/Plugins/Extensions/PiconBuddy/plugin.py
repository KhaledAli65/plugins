##############################################################################
#	(c)2022 by Oberhesse (contact through www.vuplus-support.org)
#	Creative Commons CC BY-NC-SA 3.0 License
#	Check the file "LICENSE" for more informations
# 	Images by NaseDC
##############################################################################
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ScrollLabel import ScrollLabel
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Components.Pixmap import Pixmap
from Screens.MessageBox import MessageBox
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from enigma import  eListboxPythonMultiContent, eListbox, RT_HALIGN_LEFT, RT_HALIGN_RIGHT,   \
			RT_HALIGN_CENTER, RT_WRAP, RT_VALIGN_CENTER, RT_VALIGN_TOP
from Components.Sources.List import List
from enigma import ePoint, eSize, eLabel, eTimer, ePixmap, getDesktop, gFont, gRGB, loadPNG
import os, shutil, skin, re
from .cfg import menu, getNewPath, getActPath, isWide, isCompact, scaledSkin, getOtherPathes
from .cfg import isDir, getInt, debugMode, debug, htmlStat, fontScale, yDif, isInteroperable
from .piconnames import getInteroperableNames, interoperableName, VTiName, reducedName
from .__init__ import _, noUmlaut

VERSION = 'Version 1.0'
PATH="/usr/lib/enigma2/python/Plugins/Extensions/PiconBuddy/"
ROOT= "./../../../../../../.."
scale = getDesktop(0).size().width()/1280.0  
pluginIcon = 'buddy-'+ ['hd.png','fhd.png'][ scale >1] 
	
def log(s, flag='a' ):  debug( s, flag, 'picons.txt', 2)

lastRenameSel = 0
lastRemoveAllSel = 1

def scaled(i): return int (round(i*scale))
def unScaled(i): return i/scale
	
###########################################################################
	
class  detailViewScreen (Screen):
	skin = """<screen backgroundColor="#07000000"  flags="wfNoBorder" position="center,center" size="_1280,_720" 
		title="Picon Buddy Detail View">
	<widget name="info" font="Regular;_25" foregroundColor="#cccccc" position="_230,_50" size="_1240,_540" transparent="1" />
	<widget name="logo" position="_440,_320" size="_330,_198" scale="1" alphatest="blend" transparent="1"  />
	<widget name="ok" font="Regular;_25" foregroundColor="#cccccc" position="_230,_620" size="_1240,_40" transparent="1" />
	</screen>"""

	def __init__(self, session, _parent):
		self.session = session
		Screen.__init__(self,session)
		self.skin = scaledSkin(self.skin),
		self["actions"] = ActionMap( ["OkCancelActions"],  { "cancel": self.close, "ok": self.close }, -1 )
		elem, path = _parent.actElem, _parent.piconPath
		def foundInfo(idx):  
			if (idx>=3) and ((not elem[idx]) or (not os.path.exists(path+elem[idx]))):  return '   '+_('missing')
			if (idx>=3) and os.path.islink(path+elem[idx]):  return '     [ '+_('Symlink') +' ]'
			return ''
		def elemInfo (s, idx):  return  '\n' + _(s) + ':  ' + [ elem[idx]+foundInfo(idx), '---' ][ elem[idx]=='' ]
		s = _("Picon Path") + ':  '+ path.rstrip('/')
		for idx, e in enumerate( 'Channel,Bouquet,Reference,Picon-by-Reference,Picon-by-Name'.split(',') ):  s += elemInfo ( e, idx) 
		self["info"] = Label( s.strip() )
		self["ok"] = Label( _('OK/Exit: Close') )
		self.img = path+elem[3]
		if not os.path.exists(self.img): self.img = path+elem[4]
		self["logo"] = Pixmap()
		if os.path.exists(self.img):  self.onLayoutFinish.append(self.init)
		
	def init(self): 
		inst = self["logo"].instance;  inst.setPixmapFromFile( self.img)
		if isWide():  
			x, y, w, h = inst.position().x(), inst.position().y(), inst.size().width(), inst.size().height()
			inst.resize( eSize( int(w*1.38), h ) );  inst.move(ePoint (x- int(w*0.19), y) )
			
			
###########################################################################
	

class Buddy(Screen):
	#menufont:  font and y-position used for menu 
	skin = """<screen backgroundColor="#07000000"  flags="wfNoBorder" position="center,center" size="_1280,_720" 
				title="Picon Buddy">
	<widget name="path" font="Regular;_23" foregroundColor="#cccccc" position="_25,_18" size="_1240,_40" transparent="1" />
	<widget name="info" font="Regular;_20" foregroundColor="#cccccc" position="_25,_58" size="_1240,_40" transparent="1"  />
	
	<widget name="headline1" font="Regular;_22" foregroundColor="#aaaaaa" position="_25,_63" size="_250,_36" transparent="1"  />
	<widget name="headline2" font="Regular;_22" foregroundColor="#aaaaaa" position="_360,_63" size="_550,_36" transparent="1"  />
	<widget name="headline3" font="Regular;_22" foregroundColor="#aaaaaa" position="_920,_63" size="_250,_36" transparent="1"  />
	<widget name="separator"  backgroundColor="#444444"  position="_20,_100" size="_1240,_1" zPosition="24"  />
	
	<widget name="menu" position="_20,_101" size="_1255,_574" scrollbarMode="showOnDemand" 
			foregroundColor="#fffffff"  scrollbarSliderBorderColor="#00333333" scrollbarSliderBorderWidth="1"  
			scrollbarSliderForegroundColor="#999999" scrollbarWidth="_10"  zPosition="3"  transparent="1" />
			
	<widget name="menufont"  font="Regular;_22"  position="0,_5" size="0,0"   transparent="1"  />
	<widget name="menufont_red"  foregroundColor="#ee4444"   position="0,0" size="0,0"    />
	<widget name="menufont_red_selected"  foregroundColor="#ff8888"   position="0,0" size="0,0"   />
	<widget name="menufont_blue"  foregroundColor="#55aaee"   position="0,0" size="0,0"    />
	<widget name="menufont_blue_selected"  foregroundColor="#88bbff"   position="0,0" size="0,0"   />
	<widget name="menufont_gray"  foregroundColor="#777777"   position="0,0" size="0,0"    />
	<widget name="menufont_gray_selected"  foregroundColor="#999999"   position="0,0" size="0,0"   />
	<widget name="menuseparator"  foregroundColor="#444444"  position="_0,_0" size="_0,_0" />
	<widget name="menuseparator_selected"  foregroundColor="#aaaaaa"  position="_0,_0" size="_0,_0" />
		
	<eLabel backgroundColor="#aa0000" position="_22,_690" size="_8,_30" transparent="0" />
	<widget name="key_red"  foregroundColor="#dddddd" position="_42,_687" size="_250,_30"  font="Regular;_20"  
			valign="top" transparent="1"  />
	<eLabel backgroundColor="#00aa00" position="_172,_690" size="_8,_30" transparent="0" />
	<widget name="key_green"  foregroundColor="#dddddd" position="_192,_687" size="_250,_30"  font="Regular;_20" 			valign="top"  transparent="1"    />
	<eLabel backgroundColor="#dddd33" position="_322,_690" size="_8,_30" transparent="0" />
	<widget name="key_yellow"  foregroundColor="#dddddd" position="_342,_687" size="_250,_30"  font="Regular;_20" 			valign="top"  transparent="1"    />
	<eLabel backgroundColor="#4444ff" position="_502,_690" size="_8,_30" />
	<widget name="key_blue"  foregroundColor="#dddddd" position="_522,_687" size="_250,_30"  font="Regular;_20" 			valign="top"  transparent="1"    />
	<widget name="key0"  foregroundColor="#dddddd" position="_640,_687" size="_600,_30"  font="Regular;_20" 			valign="top"  transparent="1"    />
	<widget name="key9"  foregroundColor="#dddddd" position="_800,_687" size="_600,_30"  font="Regular;_20" 			valign="top"  transparent="1"    />
	<widget name="key1"  foregroundColor="#dddddd" position="_950,_687" size="_600,_30"  font="Regular;_20" 			valign="top"  transparent="1"    />
	<widget name="keyMenu"  foregroundColor="#dddddd" position="_1190,_687" size="_600,_30"  font="Regular;_20" 			valign="top"  transparent="1"  />
	<widget name="logo" alphatest="blend" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/PiconBuddy/buddy-logo.png" 					position="_200,_175"  size="_890,_365"   scale="1"  zPosition="12" />
	<widget name="title1"  foregroundColor="#999999" position="_1130,_8" size="_250,_80"  font="Regular;_20"  			shadowColor="#113355"  shadowOffset="-2,-2" valign="top"  transparent="1"    />
	<widget name="title2"   foregroundColor="#999999" position="_1130,_30" size="_250,_80"  font="Regular;_20"  
			shadowColor="#113355"  shadowOffset="-2,-2" valign="top"  transparent="1"    />
	</screen>"""

	def __init__(self, session, args = 0):
		self.session = session
		Screen.__init__(self,session)
		self["actions"] = ActionMap( ["OkCancelActions", "ColorActions", "NumberActions", "DirectionActions", "MenuActions"], 
			{ "cancel": self.close, "green": self.green, "red": self.red, "yellow": self.swapName, "blue": self.deletePicon, "ok": self.detailView,
			"menu": self.menu,	'1': self._1, '2': self._2,  '3': self._3,  '4': self._4,  '5': self._5,  '9': self.symLinks, "0": self.removeAll }, -1)
		self["path"] = Label('')
		self["info"] = Label('')
		self["key_red"] = Label(_("Copy"))
		self["key_green"] = Label(_(" "))
		self["key_blue"] = Label(_("Delete"))
		self["key_yellow"] = Label(_("Rename"))
		self["key0"] = Label( "0: " + _("Clean Up"))
		self["key9"] = Label ( "9: "+ _("Symlinks"));  self.colFont = '#eeeeee'
		self["key1"] = Label ( "1/2/3/4/5: "+ _("Picon Path"))
		self["keyMenu"] = Label(_("Menu"))
		self["headline1"] = Label( _("Channel")+' ('+_('Bouquet')+')' ) 
		self["headline2"] = Label(_("Picon-by-Reference"))
		self["headline3"] = Label(_("Picon-by-Name"))
		self["separator"] = Label('')
		self["title1"] = Label('Picon Buddy')
		self["title2"] = Label(VERSION)
		try:
			self["menufont"] = Label('')
			self["menufont_red"] = Label('');  self.colRed = '#aa2222'
			self["menufont_red_selected"] = Label('');  self.colRedSel = '#aa2222'
			self["menufont_gray"] = Label('');  self.colGray = '#666666'
			self["menufont_gray_selected"] = Label('');  self.colGraySel = '#999999'
			self["menufont_blue"] = Label('');  self.colBlue = '#55aaee'
			self["menufont_blue_selected"] = Label('');  self.colBlueSel = '#55aaee'
			self["menuseparator"] = Label('');  self.colLine = '#444444'
			self["menuseparator_selected"] = Label('');  self.colLineSel = '#aaaaaa'
		except: pass
		self["logo"] = Pixmap()
		self.channels, self.bouquets, self.textList, self.piconPathList, self.actElem  = [], [], [], [''],  [ '', '', '' ,'', '' ]
		self.reducedNames=[];  self.notReducedNames=[]
		self.lastIdx = -1 
		self.byNameError = self.loaded = self.byRefCount = self.noRefCount = self.linkCount = self.byNameCount = 0
		self.piconPath = self.copied = self.copyChannel = self.replace = self.replaceChannel = ''
		self.copyList = []
		self.loadTimer = eTimer();  self.loadTimer.callback.append(self.readPiconsList)
		self.closePicTimer = eTimer();  self.closePicTimer.callback.append(self.closePic)
		self.closePicTimer.start(2400)
		self.renameTimer = eTimer();  self.renameTimer.callback.append(self.rename2)
		self.skin = scaledSkin(self.skin)
		try:	
			self['menu'] = MenuList(self.textList, enableWrapAround=True, content=eListboxPythonMultiContent)
			self['menu'].l.setFont(0, gFont('Regular', int(23*scale) ))
			self['menu'].l.setItemHeight(int(41*scale))
			for x in ['menu', 'headline1', 'headline2', 'headline3','separator']:  self[x].hide()
			self["menu"].setList(self.textList)
			self['menu'].onSelectionChanged.append(self.posChanged)
			self.onLayoutFinish.append(self.init)
		except Exception as e: debug( 'initMain: '+str(e), 'a')
		
	def message(self,s):  self.session.open(MessageBox,_(s), MessageBox.TYPE_INFO)
		
	def detailView(self): 
		self.getActElem()
		self.session.open( detailViewScreen, self)
		
	def getSkinAttr (self, elemId, key):
		try:
			for attr, val in self[elemId].skinAttributes:
				if attr == key:  return val
		except: pass
		return ''
		
	def scaleFont(self):
		try:
			fntData  = (self.getSkinAttr( 'menufont', 'font') + ';').split(';')
			size=getInt(fntData[1].strip())
			if (size>0):  self['menu'].l.setFont(0, gFont( fntData[0].strip(), int( size*fontScale()/100.0) ) )
			else:  self['menu'].l.setFont(0, self['menufont'].instance.getFont() )
		except: pass
		
	def init(self):
		def getSkinCol (id, default):  
			val = self.getSkinAttr( id, 'foregroundColor' );
			return [ default, val ][ (val!='') ]
			#return [ default, val ][ (val!='') and val.startswith('#') ]
		try:
			self.getChannelList()
			self.piconPath = getActPath()
			self.scaleFont()
			self.doLoad()
			self.colRed, self.colRedSel = getSkinCol('menufont_red', self.colRed ), getSkinCol('menufont_red_selected', self.colRedSel )
			self.colBlue, self.colBlueSel = getSkinCol('menufont_blue', self.colBlue ), getSkinCol('menufont_blue_selected', self.colBlueSel )
			self.colGray, self.colGraySel = getSkinCol('menufont_gray', self.colGray ), getSkinCol('menufont_gray_selected', self.colGraySel )
			self.colLine, self.colLineSel = getSkinCol('menuseparator', self.colLine ), getSkinCol('menuseparator_selected', self.colLineSel )
			self.colFont = getSkinCol('key9', self.colFont )
		except Exception as e: debug( 'init: '+str(e), 'a')
		
		
	def closePic(self):
		try: 
			self.closePicTimer.stop()
			for x in ['menu', 'headline1', 'headline2', 'headline3', 'separator']:  self[x].show()
			self['logo'].hide()
		except: pass
		
	def posChanged(self):
		try: 
			idx = self['menu'].getSelectedIndex();  name = self.textList[idx][0][0]
			self["key_green"].setText ( [_('Insert'), ''][ ( name == '') or (self.copied=='') ] )
			self["yellow"].setText ( ['0: '+ _('Rename'), '' ][ (name == '') ] )
		except: pass
		
	def getActElem(self, idx=-1):
		try: 
			if idx==-1:  idx = self['menu'].getSelectedIndex()
			self.actElem = self.textList[ idx ][0]
		except:  self.actElem =  ['', '', '' ,'', '', '']  #channel, bouquet, reference, picon
		return self.actElem
	
	###########################################################################
	
	def standardByName (self, channelName):
		if isInteroperable(): return interoperableName ( channelName )+'.png'
		else: return VTiName( channelName )
		
	def foundExtended (self, searchName):
		try:
			idx = self.reducedNames.index(searchName)
			if (idx!=None) and(idx>=0): return self.notReducedNames[idx]
		except: pass
		return ''

	def piconByName (self, channelName, read=1, extended=0 ):
		self.byNameError = 0 #channelName .find('/')>=0
		name = VTiName( channelName )
		if os.path.exists( self.piconPath + name):  return name
		newName = interoperableName( channelName ) 
		if newName and (newName!=channelName) and os.path.exists(self.piconPath+newName+'.png' ):  
			return newName + '.png'
		if read:
			nameList = getInteroperableNames(channelName)
			for x in nameList: 
				if x and os.path.exists(self.piconPath+x+'.png' ):  return  x+'.png'
				if extended and x: 
					ext= self.foundExtended(x)
					if ext and os.path.exists(self.piconPath+ ext +'.png'):  return ext+'.png'
			for x in nameList: 
				if x and os.path.exists(self.piconPath+x+'hd.png' ):  return  x+'hd.png'
				
		if newName and (newName!=channelName) and isInteroperable():  name = newName + '.png'
		return name
		
	def piconByRef (self, ref):
		if ref.startswith('4097:'): ref = '1' + ref[4:]
		return ref.rstrip(':').replace( ':' , '_')+ '.png' 
	
	def isPiconByRef (self, name):
		return (name[:1].isdigit()) and (len(name.split('_'))>=8)
	
	def isNameList(self): pass
	
	def fullChannelName (self, elem=None):  
		try:
			if elem==None: elem =self.actElem
			if elem[0] == '': return ''
			return str( elem[0] + ' ('+ elem[1]  + ')').replace(' ()','') 
		except: return ''
		
	def copyInfo(self, s):  return [ '', s+self.copyChannel, '' ][ self.copyChannel.strip()!='' ]
	
	###########################################################################
		
	def red(self, mode=-1): 	#Kopieren
		try:
			self.getActElem()
			if (not self.actElem[3]) and (not self.actElem[4]): return 1
			fName = self.piconPath + self.actElem[3]
			if (not self.actElem[3]) or not os.path.exists(fName): 
				fName = self.piconPath + self.actElem[4]
				if (not self.actElem[4]) or not os.path.exists(fName):  return 0
			self.copyChannel, self.copied = self.fullChannelName(), fName
			self.posChanged()
			for i in range(1,4):  self['headline'+str(i)].hide()
			self['info'].setText( _('Clipboard')+': '+self.copied + self.copyInfo(' - ') )
		except Exception as e: debug( 'redbut: '+str(e), 'a')
	
	def green(self):   #Einfuegen
		self.getActElem()
		self.replaceChannel, self.replace = self.fullChannelName(), self.piconPath + self.piconByRef(self.actElem[2])
		if (self.replace == self.copied) or (self.copied==''): return 1
		if not os.path.exists(self.replace):  s = _('create from')
		else:  s = _('replace by')
		saveBox = self.session.openWithCallback(self.doReplace, MessageBox, 
				self.replace+'\n' + _('Channel') +': '+self.replaceChannel+ '\n\n' +s + '\n\n' + self.copied + self.copyInfo('\n'+_('Channel')+': '),
				MessageBox.TYPE_YESNO)
		saveBox.setTitle(_(" "))
		
	def doReplace(self, answer):
		try:
			if answer is True:  
				shutil.copy( self.copied, self.replace);  self.lastIdx = self['menu'].getSelectedIndex();  self.doLoad()
		except Exception as e: debug( 'copy: '+str(e), 'a')
		
	def doDelete(self, answer, type=2):
		try:
			if answer !=True:  return 0
			self.lastIdx = self['menu'].getSelectedIndex();  self.getActElem()
			if (type!=1) and self.actElem[3]  and os.path.exists(self.piconPath + self.actElem[3]):  
				if os.path.islink(self.piconPath+self.actElem[3]):  os.unlink(self.piconPath+self.actElem[3]) #remove symlink
				else:  os.remove(self.piconPath + self.actElem[3])
			if (type!=0) and self.actElem[4] and os.path.exists(self.piconPath+self.actElem[4]):  os.remove(self.piconPath + self.actElem[4])
			self.doLoad()
		except: pass
		
	def delChoice(self, answer):
		try: 
			if answer!=None:  self.doDelete(True, int(answer[1]) )
		except: pass
		
	def deletePicon(self): #delete selected picon
		try:
			self.getActElem();  name, fileRef, fileName = self.fullChannelName(), self.actElem[3], self.actElem[4]
			okRef = (self.actElem[3]  and os.path.exists(self.piconPath+self.actElem[3])) 
			okName = (self.actElem[4]  and os.path.exists(self.piconPath+self.actElem[4]))
			isLink = (self.actElem[3]  and os.path.islink(self.piconPath+self.actElem[3])) and okName
			if not (okRef or okName): return 1
			#if okRef and okName: file = fileRef+ ' + ' +fileName
			if okRef and okName and not isLink:
				delChoices = [ ( _('Delete By-Ref-Picon'), '0'), ( _('Delete By-Name-Picon'), '1'),  ( _('Delete All'), '2') ]
				self.session.openWithCallback( self.delChoice, ChoiceBox, title=_("Delete Picon?"),  list=delChoices  )
				return 1
			elif okRef: file = fileRef
			else: file = fileName
			saveBox = self.session.openWithCallback(self.doDelete, MessageBox, 
				_('Delete Picon?')+'\n\n'+ file +'\n' + _('Channel') + ': '+str(name), MessageBox.TYPE_YESNO)
			saveBox.setTitle(_(" "))
		except Exception as e: debug( 'yellow: '+str(e), 'a')
		
		
	###########################################################################
	
	def textRegist (self,   x, y, w, h, _font ,_flags, _text ):
		self.textList.append( MultiContentEntryText ( pos=(scaled(x), scaled(y)),  size=(scaled(w), scaled(h)), 
						font=_font,  flags=_flags,  text=_text ) )

	def getChannelList (self):
		from ServiceReference import ServiceReference
		from Screens.ChannelSelection import service_types_tv, service_types_radio
		from enigma import  eServiceReference, eServiceCenter
		def radioName(ref):
			ref=ref.replace(':','_').replace('1_0_2_','');  ref = (ref.upper().split('_1_C'))[0];  return [  ref, 'Radio' ][ref=='']
		def getServiceList( ref ):
			root = eServiceReference( str(ref) )
			serviceHandler = eServiceCenter.getInstance()
			return serviceHandler.list( root ).getContent( "SN", True)
		allBouquets = getServiceList( service_types_tv + ' FROM BOUQUET "bouquets.tv" ORDER BY bouquet')
		radioBouquets = getServiceList(service_types_radio + ' FROM BOUQUET "bouquets.radio" ORDER BY bouquet')
		tvLen = len(allBouquets)
		allBouquets = allBouquets + radioBouquets
		self.channels = [];   self.bouquets=[]
		for idx, bouquet in enumerate(allBouquets):
			self.bouquets.append(bouquet[1]);  isRadio=(idx>=tvLen)
			sList = getServiceList( bouquet[0] )	
			for ( ref, name) in sList:  
				ref = ref.strip()
				if ref.find('::')>=0:  ref= (ref.split('::'))[0] + ':'
				if ref.find('http')>=0:  ref= (ref.split('http'))[0]
				#if ref.startswith('4097:'): ref = '1' + ref[4:]
				if name=='<n/a>' and isRadio:  name = radioName(ref)
				self.channels.append ( [str(name).strip(),  str(bouquet[1]), str(ref) ] )  
				
		
	def doLoad(self, dummy=0):
		self['path'].setText('Loading'+' '+self.piconPath + '...')
		self.scaleFont()
		self.loadTimer.start(50)
		
	def htmlHead(self):
		html = '<html><head>\n<style>\ntd {border:1px solid #aaaaaa;margin:0;padding:10px;spacing:0;vertical-align:top}'
		html += '\ntable {border-collapse:collapse}'
		html += '\nhtml,body,td { font-size:15px; font-family:helvetica,sansserif,arial}\n</style></head>\n'
		return html
		
	def parseCol (self, colStr ):
		if colStr.startswith('#'):  return int( colStr[1:], 0x10 )
		try:  return int(skin.parseColor(colStr).argb())
		except: pass
		return int( 'ffffff', 0x10 )
		
		
	def markSymLink(self):  #pass
		try: 
			col = [self.colFont, self.colBlue][self.hasLink];  self['key9'].instance.setForegroundColor( self.parseCol(col) )
			self["headline2"].setText(_("Picon-by-Reference") + ['' , ' / '+_('Symlink') ][self.hasLink]  )
		except Exception as e: debug( 'markSymLink: '+str(e), 'a')
						
	def readPiconsList(self):
		try:
			def entry ( x, y, w, h, _font,_flags, _text, found=True, gray=False, blue=False):
				if not found:  col, colSel = self.parseCol(self.colRed), self.parseCol(self.colRedSel) 
				else: col, colSel = None, None 
				if gray: col, colSel = self.parseCol(self.colGray), self.parseCol(self.colGraySel) 
				if blue:  col, colSel = self.parseCol(self.colBlue), self.parseCol(self.colBlueSel) 
				return  MultiContentEntryText ( pos=(scaled(x), scaled(y)),  
					size=(scaled(w), scaled(h)),   font=_font,  flags=_flags, color=col, color_sel=colSel, text=_text) 
					
			def lineEntry ( x ):
				col0, col1 = self.parseCol(self.colLine), self.parseCol(self.colLineSel) 
				return MultiContentEntryText ( pos=(scaled(x),0), size=(scaled(1),scaled(52)), font=0, flags=RT_HALIGN_LEFT, text='', 
						color=0, color_sel=0, backcolor=col0, backcolor_sel= col1) 
					
			L, C, R = RT_HALIGN_LEFT | RT_VALIGN_TOP, RT_HALIGN_CENTER | RT_VALIGN_TOP, RT_HALIGN_RIGHT | RT_VALIGN_TOP
						
			def piconEntry (x, y, w, h, picon ):
				elem= MultiContentEntryPixmapAlphaTest( pos=(scaled(x), scaled(y)),  
						size=(scaled(w), scaled(h)), png=loadPNG(picon) )
				l = list(elem);  l[8] = 4;  elem = tuple(l) 
				return elem
				
			def out ( res, yPos, name, piconRef, piconName, wide, compact):
				nameShort = (name.rsplit(' ('))[0]
				if not compact:  yPos += 5
				yPos += yDif()-5
				res.append (entry ( 5, yPos,  319,42, 0, L, name, True,True) )
				res.append (entry ( 5, yPos,  319,42, 0, L, nameShort) )
				
				picRef = self.piconPath+piconRef;  
				foundRef = piconRef and os.path.exists(picRef)
				foundLink = piconRef and os.path.islink(picRef)
				res.append( lineEntry (325) )
				if compact:  xDif, y, w, h = [7,-6][wide], 0, [67,92][wide], 40
				else:  xDif, y, w, h = [2,-15][wide], 2, [80,110][wide], 48
				
				res.append( entry ( 340,  yPos, 438+xDif,40,  0, L,  piconRef, foundRef, False, foundLink ) )
				if  foundRef:  res.append( piconEntry (780 + xDif, y, w, h,  picRef) )
				
				picName = self.piconPath+piconName;  foundName = os.path.exists(picName)
				res.append( lineEntry (885) )
				res.append( entry ( 900, yPos,  239+xDif, 40,  0, L,  piconName, foundName ) )
				if foundName:  res.append( piconEntry (1140 + xDif, y, w, h,  picName) )
				return res
				
			def td(s, style=''):  return '<td' +style+ '>'+s+'</td>'
			def tdCenter(s):  return '<td style="text-align:center">' + s + '</td>'
			def tdImg(s):  
				if os.path.exists(s): s = '<img height="40px" src="' + ROOT + s + '"></img>'
				else: s = '<small><br>' + _('missing') + '</small>'
				return tdCenter(s)
				
			self.loadTimer.stop()
			self.textList=[];  pList = [];  notUsed = [];  statS = '';  self.hasLink = pSum = 0
			self.byRefCount = self.noRefCount = self.linkCount = self.byNameCount = 0
			html = self.htmlHead() + '<body>\n<big>'+self.piconPath.rstrip('/') + '</big><br><table>\n<tr>'+td(_('Channel'))+td(_('Bouquet'))
			html += td('Reference<br>Picon-by-Reference<br>Picon-by-Name') + td('Picon<br><small>(by Reference)</small>') 
			html += td('Picon<br><small>(by Name)</small>') + '</tr>'
			log(self.piconPath,'w')
			pathOk = isDir( self.piconPath.rstrip('/'))
			y0 = unScaled(self['menufont'].instance.position().y());  y1=y0
			wide, compact = isWide(), isCompact();  iH = int([52,41][compact]*scale)
			self['menu'].l.setItemHeight(iH)
			
			self.reducedNames=[];  self.notReducedNames=[]  #regist all picons
			for f in os.listdir(self.piconPath):
				if str(f).endswith('.png') and (not os.path.islink(self.piconPath+str(f))) and (not self.isPiconByRef(str(f))):
					fN = str(f)[:-4]; self.notReducedNames.append(fN);   self.reducedNames.append( reducedName(fN))
					
			for x in self.channels: 
				name, bouquet, ref = x[0], x[1], x[2]
				piconRef = self.piconByRef(ref) ###ref.rstrip(':').replace(':','_')+ '.png' 
				piconRefFull = self.piconPath + piconRef
				piconName = self.piconByName(x[0], True)  #.replace('+', 'plus').replace('/','or') + '.png'  #channelbyname
				if not os.path.exists(self.piconPath + piconName):  piconName = self.piconByName(x[0], True, True)
				piconNameFull = self.piconPath + piconName
				if self.byNameError:  piconName, piconNameFull = '', ''
				if not pathOk:  foundRef, foundName = False, False
				else: foundRef, foundName = os.path.exists(piconRefFull), os.path.exists(piconNameFull)
				if foundRef:  pList.append(piconRef);  self.byRefCount += 1
				if foundName:  pList.append(piconName);  self.byNameCount += 1
				if foundRef and os.path.islink(piconRefFull):  self.linkCount += 1
				if foundName and not foundRef:   self.noRefCount += 1
				res=[ (name, bouquet, ref, piconRef, piconName) ]
				res = out( res, y0, self.fullChannelName(res[0]), piconRef, piconName, wide, compact)
				self.textList.append(res )
				html += '\n<tr>'+ td(name) + td(bouquet) + td(ref+'<br>'+piconRef+'<br>'+piconName) + tdImg(piconRefFull)
				html += tdImg(piconNameFull) + '</tr>'
				statS = name + ', ' + bouquet + ', ' + ref + ', ' + piconRefFull + [ ' - '+_('MISSING'), '' ][foundRef] 
				statS += ', ' + piconNameFull + [ ' - '+_('MISSING'), '' ][foundName]
				log(statS)
			
			if pathOk:
				for f in os.listdir(self.piconPath):
					if str(f).endswith('.png') and not os.path.islink(self.piconPath+str(f)):
						pSum += 1
						if (not str(f) in pList) and ( str(f).endswith('.png')): notUsed.append( str(f))
			notUsed.sort();  #pSum = len(pList) + len(notUsed)
			for p in notUsed:
				piconFull = self.piconPath +p
				html += '\n<tr>' + td('---') + td('---') + td(p)
				if self.isPiconByRef(p):  res=[ ('', '', '', p, '') ];  html += tdImg(piconFull) + td('&nbsp;') + '</tr>'
				else:  res=[ ('', '', '', '', p) ];  html += td('&nbsp;')  + tdImg(piconFull) +'</tr>'
				log( _('unassigned') +': ' + piconFull  )
				res = out (res, y0,  '---', res[0][3], res[0][4], wide, compact)
				self.textList.append(res)
			self["menu"].setList(self.textList)
			self.replace = self.replaceChannel = ''
			stat = str(pSum)+ ' '+_('Picons' )
			self["path"].setText( self.piconPath + '         ('+ stat+')')
			if self.lastIdx>=0:  self["menu"].moveToIndex( min(self.lastIdx,len(self.textList)-1)   )
			if htmlStat(): html += '</table></body></html>';  f = open( PATH + 'picons.html' , 'w');  f.write( html);  f.close()
		except Exception as e: debug( 'readPicons: '+str(e), 'a')
		self.loaded = 1
		self.markSymLink()
		
		
	###########################################################################
			
	def removePicons (self, newPath):     #type:   0=move   1=delete
		newPath = newPath.rstrip('/')
		isBak = (newPath == self.piconPath + 'bak' )
		_delete = (newPath == '')
		try:  
			if newPath.endswith( '/bak' ):
				if not os.path.exists (newPath):  os.mkdir(newPath)
			for x in self.textList:
				name, piconRef, piconName = x[0][0], x[0][3], x[0][4]
				if (name == '') and piconRef and os.path.exists(self.piconPath + piconRef):
					picon = self.piconPath + piconRef
					if _delete: os.remove(picon)
					else: shutil.move( picon, picon.replace(self.piconPath, newPath+'/') )
				if (name == '') and piconName and os.path.exists(self.piconPath + piconName):
					picon = self.piconPath + piconName
					if _delete: os.remove(picon)
					else: shutil.move( picon, picon.replace(self.piconPath, newPath+'/') )
		except Exception as e: debug( 'removepicons: '+str(e), 'a')
	
		
	def callBackClearAll( self, answer):
		if answer==None: return 1
		global lastRemoveAllSel;  lastRemoveAllSel = getInt(answer[2])
		self.removePicons(answer[1])
		self.doLoad()
		
		
	def removeAll( self):
		otherPathes = getOtherPathes(self.piconPath);  bak = self.piconPath + 'bak' 
		choices = [ (_('Delete all unassigned Picons'), '', '0') ]
		choices.append ( [_('Move unassigned Picons to ./bak (Subdirectory)'), bak, '1' ] )
		pos = 2
		for o in otherPathes:
			if o!=bak: choices.append( [_('Move unassigned Picons to')+' '+o, o, str(pos) ] );  pos += 1
		self.session.openWithCallback( self.callBackClearAll, ChoiceBox, title=_('Delete unassigned Picons'),  
					list=choices, selection=lastRemoveAllSel  )
					
		
	def alternativePicon (self, idx):  #check if a picon-by-ref exists for another channel with the same name
		name , reduced = self.piconByName( self.actElem[0],True), reducedName(self.actElem[0])
		for i, e in enumerate(self.textList):
			if e[0][0] == '':  break  #end of channelllist
			if (idx != i ) and self.piconByName(e[0][0], True) == name: #same channel name
				byRef = self.piconPath + self.piconByRef (e[0][2] )
				if os.path.exists(byRef): return byRef
		for i, e in enumerate(self.textList):
			if e[0][0] == '':  break  #end of channelllist
			if (idx != i ) and reducedName(e[0][0]) == reduced: #same channel name
				byRef = self.piconPath + self.piconByRef (e[0][2] )
				if os.path.exists(byRef): return byRef
		return ''
		
		
	def restoreOtherRef ( self, renamedName, idx, newName ):  # byName to byRef:  restore ByRef for other Channels with same byName
		for i, e in enumerate(self.textList): 		#...that just lost their byRef-Picon and restore the reference
			if e[0][0] == '': return ''  #end of channelllst
			refFile, nameFile = self.piconPath+e[0][3], self.piconPath+e[0][4]
			if (idx != i ) and (renamedName==nameFile) :  #found other channel with same ByName
				if os.path.islink(refFile): os.unlink(refFile)
				if not os.path.exists(refFile):  shutil.copyfile(newName, refFile )
				
		
	def rename( self, answer, secondRun=0):
		if answer==None: return 0
		choice = getInt(answer[1]);  RenameToRef = choice in [ 0, 2];  renameToName = not RenameToRef
		global lastRenameSel;  lastRenameSel = choice
		
		def renameElem(idx):
			try:
				self.getActElem(idx)
				if not self.actElem[0]: return 0
				byName = self.piconPath + self.piconByName( self.actElem[0], RenameToRef)
				byName2 = self.piconPath + self.standardByName( self.actElem[0] )
				if self.byNameError: return 0
				byRef = self.piconPath + self.piconByRef (self.actElem[2])
				if (RenameToRef) and os.path.exists(byRef) and not os.path.exists(byName): return 0
				if (RenameToRef) and os.path.islink(byRef) and os.path.exists(byName):  os.unlink(byRef)
				
				def renamePicon (_from, _to):
					if _from.strip() == _to.strip(): return 0
					if os.path.islink(_to) and os.path.exists(_from):  os.unlink(_to)
					if os.path.exists(_from):  
						shutil.move( _from, _to )
						if choice==0:  self.restoreOtherRef ( _from, idx, _to )
					elif RenameToRef: 
						_from = self.alternativePicon(idx)   #if byName already renamed to another byRef
						if _from and  (_from.strip() != _to.strip()):  shutil.copyfile(_from, _to )
						
				if RenameToRef:  
					renamePicon(byName, byRef)
				else:
					if os.path.exists(byName) and not os.path.exists(byName2):  
						hasLink = os.path.islink(byRef) #save symlink
						if hasLink: os.unlink(byRef)
						renamePicon(byName, byName2)
						if hasLink:  os.symlink( byName2, byRef) #set new symlink
					elif os.path.exists(byRef) and not os.path.islink(byRef):
						renamePicon(byRef, byName)
			except Exception as e: debug( 'rename: '+str(e), 'a')
			
		if (choice == 2) and self.hasLink and not secondRun:  self.removeLinksAndRename(); return 1  #remove ByRef-Symlinks first
		if choice in [ 0, 1 ]:  renameElem(-1)
		else:
			for idx, e in enumerate(self.textList):
				if e[0][0] == '': break
				renameElem(idx)
		self.doLoad()
		if renameToName and (self.noRefCount>0) and isInteroperable():  self.message(_("Symlinks should be set (Press '9')"))
			
		
	def rename2(self):  self.renameTimer.stop();  self.rename( ['2','2'],True) #self.doLoad();  self.message('ok') #
	def removeLinksAndRename(self):  self.changeSymLinks( ['1','1'] , False);  self.doLoad();  self.renameTimer.start(1000)
	
	def swapName( self): #button 1
		self.getActElem();  name = self.actElem[0]
		if name == '': return 1
		choices = [ ( name+' '+ _('to Picon-by-Reference (Standard)'), '0'), 
					( name+' '+_('to Picon-by-Name'), '1'),
					(_('ALL Channels to Picon-by-Reference (Standard)'), '2'), 
					(_('ALL Channels to Picon-by-Name'), '3') ]
		self.session.openWithCallback( self.rename, ChoiceBox, title=_("Rename"),  list=choices, selection=lastRenameSel  )
		
	##### SYMLINKS ###############################################################
		
	def changeSymLinks( self, answer=None, reload=True):
		if answer == None: return 0
		try:
			def createLink (elem):
				if not elem[1]: return 0 #unused
				byRef, byName =  self.piconPath+elem[3], self.piconPath+elem[4]
				if  os.path.exists(byRef) and (not os.path.islink(byRef)) and os.path.exists(byName):
					shutil.move( byRef, byName[:-4]+'.bak.png' )
					if os.path.exists(byRef): os.remove(byRef)
				if ( (not os.path.exists(byRef)) or os.path.islink(byRef) ) and os.path.exists(byName):  
					if os.path.islink(byRef):  os.unlink(byRef)
					os.symlink( byName, byRef)
			if (answer[1] == '0') and (self.byNameCount==0):  self.message('No Picons-by-Name found'); return 0
			for f in os.listdir(self.piconPath):
				if  (str(f).endswith('.png')) and os.path.islink(self.piconPath+str(f)): 
					os.unlink(self.piconPath+str(f))
			if answer[1] == '0':
				for x in self.textList: createLink( x[0] )
		except Exception as e: debug( 'symlink: '+str(e), 'a')
		if reload: self.doLoad()
		
		
	def symLinks( self ):
		choices = [ (_('Create/Refresh By-Ref-Symlinks for all By-Name-Files'), '0'), ( _('Remove all Symlinks'), '1')  ]
		self.session.openWithCallback( self.changeSymLinks, ChoiceBox, title=_("Symlinks"),  list=choices )
		
	###########################################################################
		
	def _1( self, nr = 1 ):
		try:
			newPath = getNewPath(nr)
			if newPath: self.piconPath = newPath;  self.doLoad()
		except Exception as e: debug( 'ChDir: '+str(e), 'a')
		
	def _2(self):  self._1(2)
	def _3(self):  self._1(3)
	def _4(self):  self._1(4)
	def _5(self):  self._1(5)
			
	def menu( self):   self.session.openWithCallback( self.doLoad, menu) 
	
	###########################################################################
		
def main (session, **kwargs):  session.open(Buddy)

def Plugins(**kwargs):
	return [	 PluginDescriptor( name = "Picon Buddy", description = _("Another Picon Manager"), 
			where = [PluginDescriptor.WHERE_PLUGINMENU], icon = pluginIcon ,fnc = main )  ]




