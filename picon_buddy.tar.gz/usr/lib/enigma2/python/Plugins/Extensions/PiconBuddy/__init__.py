# -*- coding: utf-8 -*-
import Plugins.Plugin
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
import gettext

def localeInit():
	lang = language.getLanguage()
	gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
	gettext.textdomain("enigma2")
	gettext.bindtextdomain("PiconBuddy", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/PiconBuddy/locale/"))
	
def umlaut (s):
	repAou = [  ('_ae','ä'), ('_oe','ö'),  ('_ue','ü'), ('_Ae','Ä'), ('_Oe','Ö'),  ('_Ue','Ü'),  ('_ss', 'ß' ) ]
	for ch in repAou: s = s.replace( ch[0], ch[1] )
	return s	
		
def noUmlaut (s):
	repAou = [  ('ae','ä'), ('oe','ö'),  ('ue','ü'), ('Ae','Ä'), ('Oe','Ö'),  ('Ue','Ü'),  ('ss', 'ß' ) ]
	for ch in repAou: s = s.replace( ch[1], ch[0] )
	return s

def _(txt):
	t = gettext.dgettext("PiconBuddy", txt)
	if t == txt:  t = gettext.gettext(t)
	return umlaut (t)

localeInit()
language.addCallback(localeInit)