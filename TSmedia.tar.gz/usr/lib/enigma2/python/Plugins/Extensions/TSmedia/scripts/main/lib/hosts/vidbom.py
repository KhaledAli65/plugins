# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts/main/lib/hosts/vidbom.py
import requests, re
sgn = requests.Session()

def decode1(text):
    text = re.sub('\\s+|/\\*.*?\\*/', '', text)
    data = text.split('+(\xef\xbe\x9f\xd0\x94\xef\xbe\x9f)[\xef\xbe\x9fo\xef\xbe\x9f]')[1]
    chars = data.split('+(\xef\xbe\x9f\xd0\x94\xef\xbe\x9f)[\xef\xbe\x9f\xce\xb5\xef\xbe\x9f]+')[1:]
    txt = ''
    for char in chars:
        char = char.replace('(o\xef\xbe\x9f\xef\xbd\xb0\xef\xbe\x9fo)', 'u').replace('c', '0').replace("(\xef\xbe\x9f\xd0\x94\xef\xbe\x9f)['0']", 'c').replace('\xef\xbe\x9f\xce\x98\xef\xbe\x9f', '1').replace('!+[]', '1').replace('-~', '1+').replace('o', '3').replace('_', '3').replace('\xef\xbe\x9f\xef\xbd\xb0\xef\xbe\x9f', '4').replace('(+', '(')
        char = re.sub('\\((\\d)\\)', '\\1', char)
        c = ''
        subchar = ''
        for v in char:
            c += v
            try:
                x = c
                subchar += str(eval(x))
                c = ''
            except:
                pass

        if subchar != '':
            txt += subchar + '|'

    txt = txt[:-1].replace('+', '')
    txt_result = ''.join([ chr(int(n, 8)) for n in txt.split('|') ])
    return toStringCases(txt_result)


def toStringCases(txt_result):
    sum_base = ''
    m3 = False
    if '.toString(' in txt_result:
        if '+(' in txt_result:
            m3 = True
            sum_base = '+' + find_single_match(txt_result, '.toString...(\\d+).')
            txt_pre_temp = find_multiple_matches(txt_result, '..(\\d),(\\d+).')
            txt_temp = [ (n, b) for b, n in txt_pre_temp ]
        else:
            txt_temp = find_multiple_matches(txt_result, '(\\d+)\\.0.\\w+.([^\\)]+).')
        for numero, base in txt_temp:
            code = toString(int(numero), eval(base + sum_base))
            if m3:
                txt_result = re.sub('"|\\+', '', txt_result.replace('(' + base + ',' + numero + ')', code))
            else:
                txt_result = re.sub("'|\\+", '', txt_result.replace(numero + '.0.toString(' + base + ')', code))

    return txt_result


def toString(number, base):
    string = '0123456789abcdefghijklmnopqrstuvwxyz'
    if number < base:
        return string[number]
    else:
        return toString(number // base, base) + string[number % base]


def find_single_match(data, patron, index = 0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except:
        return ''


def find_multiple_matches(text, pattern):
    return re.findall(pattern, text, re.DOTALL)


def get_eval_function(data, sPattern):
    r = re.search(sPattern, data, re.DOTALL + re.IGNORECASE)
    return r


def setUrl(sUrl):
    __sUrl = ''
    if '=img.' in sUrl:
        __sUrl = sUrl.split('=img.')[0]
    elif 'embed-' in sUrl:
        __sUrl = sUrl.split('embed-')[1]
    __sUrl = __sUrl.replace('https://www.vidbm.com/', '')
    __sUrl = __sUrl.replace('embed-', '')
    __sUrl = __sUrl.replace('emb.html?', '')
    __sUrl = __sUrl.replace('.html?auto=1', '')
    __sUrl = __sUrl.replace('.html', '')
    return __sUrl


def get_video_url(url):
    _id = setUrl(url)
    print '_id_id_id_id_id_id_id_id_id_id_id_id_id_id_id=====================', _id
    url = 'https://www.vidbm.com/embed-' + str(_id) + '.html?'
    Urlo = ''
    video_urls = []
    hdr = {'Host': 'vidbm.com',
     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
     'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
     'Accept-Encoding': 'gzip, deflate',
     'Connection': 'keep-alive',
     'Upgrade-Insecure-Requests': '1'}
    data = sgn.get(url, headers=hdr, verify=False).content
    sPattern = '\\\xef\xbe\x9f\xcf\x89\\\xef\xbe\x9f\\\xef\xbe\x89=(.+?)</script>'
    code = get_eval_function(data, sPattern).group(1)
    code = decode1(code)
    if code:
        sPattern = 'file:"(.+?)",label:"(.+?)"'
        code = get_eval_function(code, sPattern)
        a, b = code.group(1), code.group(2)
        b = b.replace('/', '_')
        w = ('Cool_* vidbom [ ' + b + ' ]', a)
        video_urls.append(w)
    else:
        w = ('Ooops_* vidbom ', 'http://error')
        video_urls.append(w)
    return video_urls