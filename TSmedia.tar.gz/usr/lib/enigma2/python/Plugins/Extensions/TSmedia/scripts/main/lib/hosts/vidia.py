import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
import requests,re
sgn = requests.Session()
from jsunpack import unpack
def get_eval_function(data,sPattern):
    r = re.search(sPattern, data, re.DOTALL + re.IGNORECASE)
    return r
def get_video_vidia(url):
    Urlo = ''
    video_urls = []
    data = sgn.get(url,verify=False).content
    sPattern = "javascript'>(eval.*?)</script>"
    code = get_eval_function(data,sPattern)
    code = code.group()
    code = unpack(code)
    if code:
        sPattern = '''\{sources:\[\{file:".+?"\},\{file:"(.+?)",label:""\}'''
        b = get_eval_function(code,sPattern)
        if b:
            b = b.group(1)
            print "coucouc",b
            w = ('Cool_* vidia',b)
            video_urls.append(w)
        else:
            rgx = '''\{player.src\(\[\{src:"(.+?)",type'''
            b = re.findall(rgx,code)
            if b:
                b = b[0]
                w = ('Cool_* vidia',b)
                video_urls.append(w)
    else:
        w = ('Ooops_* vidia','http://error')
        video_urls.append(w)
    return video_urls
S1="https://www.vidia.tv/embed-8d5ythf3jjea.html?Key=daGPpwRx6OkPnACZejDc0A&Expires=1600904864"
S2="https://www.vidia.tv/embed-b3mbj50bgf7p.html?Key=9a5Eid07f8jeRISXb0KcTw&Expires=1600951750"
S3="https://www.vidia.tv/embed-b3mbj50bgf7p.html?Key=GlkofavcmxA624dB0fPxkg&Expires=1600967440"
print get_video_vidia(S3)
