import os,sys,json,ast,urllib



def addscripts():

        scriptsPath ='/usr/lib/enigma2/python/Plugins/Extensions/TSmedia/scripts'
         
                   
             
        for name in os.listdir(scriptsPath):
                       if not os.path.isfile(name) and not name.endswith(".py") and not name.endswith(".pyo") and not name.endswith(".pyc"):

                          pacPath=os.path.join(scriptsPath,name)
                          sys.path.append(pacPath+"/lib")
                          if os.path.exists(pacPath+"/lib/libs"):
                             sys.path.append(pacPath+"/lib/libs")
                         
addscripts()      




from iTools import printD,printE
try:

        
        paramFile="/tmp/TSmedia/params.json"
        with open(paramFile) as outputFile:
            cParams = json.load(outputFile)
        print "Input params-syspath",cParams
       
        
        try:
          print "starting process-syspath"      
          from default import start
          datalist=start(cParams)
          try:
            print "datalist-length",len(datalist)     
            print "datalist-syspath",datalist[0]
          except:
                  pass
          if len(datalist)>0:      
                  dataFile='/tmp/TSmedia/data'
                  if os.path.exists(dataFile):
                          os.remove(dataFile)
                  try:        
                          with open(dataFile, 'w') as outfile:
                            json.dump(datalist, outfile)
                  except Exception as error:
                      
                      printE()
                      print "Error:", str(error)

        except:
                printE()
                      
except Exception as error:
        
        print "error",str(error)
        printE()
