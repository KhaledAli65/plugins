import HTMLParser
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
import requests,re
Sgn = requests.Session()
def permutliste(seq, er=False):
    p = [seq]
    n = len(seq)
    for k in xrange(0,n-1):
        for i in xrange(0, len(p)):
            z = p[i][:]
            for c in xrange(0,n-k-1):
                z.append(z.pop(k))
                if er==False or (z not in p):
                    p.append(z[:])
    return p
def arrangliste(seq, k):
    aime = []
    """Liste des arrangements des objets de la liste seq pris k a k"""
    p = []
    i, imax = 0, 2**len(seq)-1
    while i<=imax:
        s = []
        j, jmax = 0, len(seq)-1
        while j<=jmax:
            if (i>>j)&1==1:
                s.append(seq[j])
            j += 1
        if len(s)==k:
            v = permutliste(s)
            p.extend(v)
        i += 1
    for lst in p:
        a = str(lst[0])+str(lst[1])+str(lst[2])+str(lst[3])
        aime.append(a)
    return aime
def decode_num(s):
    x=''
    list1 = []
    for h in s:
        a = HTMLParser.HTMLParser().unescape(h)
        list1.append(a)
    return arrangliste(list1,4)
def get_video_url(url):
    Infos = ''
    video_urls = []
    url = url.replace('embed-','').replace('.html','')
    print "URL = ",url
    hddr = {'Host': 'playnow.ac',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://playnow.ac',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'}
    data1=Sgn.get(url,verify=False).content
    r1 = '''name="id" value="(.+?)">'''
    _id = re.findall(r1,data1)[0]
    r2 = '''name="rand" value="(.+?)">'''
    rand = re.findall(r2,data1)[0]
    r3 = '''<span style='position:absolute;padding-left.+?>(.+?)</span>'''
    code = re.findall(r3,data1)
    z = decode_num(code)
    print z
    prm = {
    "op": "download2",
    "id": _id,
    "rand": rand,
    "referer": "",
    "method_free": "",
    "method_premium": "",
    "adblock_detected": "1",
    "code": str(z)}
    print prm
    hddr.update({'Referer':url})
    print url
    for q in z:
        prm.update({"code":q})
        _dons = requests.post(url,headers=hddr,data=prm,verify=False).content
        ymx = '''<a href="(.+?)"><button class="lastbtn"><span>Download NOW</span></button></a>'''
        href = re.findall(ymx,_dons)
        if href:
            print q
            print z.index(q)
            print href
            video_urls.append(("Cool_playnow",href[0]))
            break
    return video_urls




if __name__=='__main__':
     
     url0='https://playnow.ac/embed-vdvrift38kuj.html'
     print get_video_url(url0)