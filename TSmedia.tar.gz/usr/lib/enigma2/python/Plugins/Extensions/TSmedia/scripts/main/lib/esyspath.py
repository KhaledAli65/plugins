
import os,sys
if "scripts" in __file__ :
 appPath=os.path.split(__file__)[0].split("scripts")[0]       
else:        
  appPath=os.path.split(__file__)[0].split("lib")[0]
def addscripts():

        scriptsPath =os.path.join(appPath,"scripts")
                   
             
        for name in os.listdir(scriptsPath):
                       if not os.path.isfile(name) and not name.endswith(".py") and not name.endswith(".pyo") and not name.endswith(".pyc"):

                          pacPath=os.path.join(scriptsPath,name)
                          sys.path.append(pacPath+"/lib")
                          if os.path.exists(pacPath+"/lib/libs"):
                             sys.path.append(pacPath+"/lib/libs")
                         

addscripts()
