
import sys,wsyspath,urllib
appPath=__file__.split("scripts")[0][:-1]
host,url=open(appPath+"/tmp/hostlink").read().split(";")
print "host",host
print "url",url
if url.strip()!="none":
   exec "from "+host+" import get_video_url" 
   print get_video_url(url)
else:
    exec "from "+host+" import testLink"
    print testLink()
