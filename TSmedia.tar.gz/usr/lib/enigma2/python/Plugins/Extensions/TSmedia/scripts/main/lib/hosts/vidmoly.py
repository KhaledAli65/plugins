import requests,re
S = requests.Session()
def get_video_url(url):
    ListVideos = []
    _r = S.get(url).content
    rgx = '''{file:"(.+?)",label:"(.+?)"}'''
    _don = re.findall(rgx,_r)
    if _don:
        for x,y in _don:
            if '.mpd' in x:continue
            w=('Cool_vidmoly_'+str(y),x)
            ListVideos.append(w)
    else:
        w=('Ooops_vidmoly_','http://Error')
        ListVideos.append(w)
    return ListVideos