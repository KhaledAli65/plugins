# -*- coding: utf8 -*-
from iTools import CBaseAddonClass
self = CBaseAddonClass()
Agent = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; …) Gecko/20100101 Firefox/65.0'}
import requests,re
Sgn = requests.Session()
from jsunpack import unpack
def get_M3u(url):
    Mlist = []
    html = self.getPage(url)
    if html:
        _srcs = re.findall(r'#EXT-X-STREAM-INF:PROGRAM-ID=1,.+?RESOLUTION=(.+?),.+?http(.+?).m3u8', html,re.S)
        if _srcs:
            for qlt,href in _srcs:
                qlt = qlt.split('x')[1]+"p"
                href=href.replace('\n','')
                href="http"+href+".m3u8"
                Mlist.append((qlt,href))
            return Mlist
        else:return 'nada'
    else:return 'nada'
def get_video_url(url):
    listServers= []
    Listo = []
    data2 = self.getPage(url)
    rgx = '''sources: \[\{src: "(.+?)"'''
    film = re.findall(rgx,data2)
    if film:
        if ".m3u8" in film[0]:
            links = get_M3u(film[0])
            if links!='nada':
                for x in links:
                    listServers.append(('Cool_vidshare ['+x[0]+']',x[1]))
                #return Listo
            else:
                w = ('Cool_vidshare',film[0])
                listServers.append(w)
                #return listServers
        if ".m3u8" not in film[0]:
            w = ('Cool_vidshare',film[0])
            listServers.append(w)
            #return listServers
    else:
        w = ('Oops_vidshare','Error')
        listServers.append(w)
    return listServers




if __name__=='__main__':
    url0='https://vidshar.tv/embed-wnwjb9ckfxmj.html'
    print get_video_url(url0)