import os,sys,json,ast,io

appPath=os.path.split(__file__)[0].split("addons")[0]
Params=sys.argv[2]
def addscripts():

        scriptsPath =os.path.join(appPath,"scripts")
                   
             
        for name in os.listdir(scriptsPath):
                       if not os.path.isfile(name) and not name.endswith(".py") and not name.endswith(".pyo") and not name.endswith(".pyoc"):

                          pacPath=os.path.join(scriptsPath,name)
                          sys.path.append(pacPath+"/lib")
                          if os.path.exists(pacPath+"/lib/libs"):
                             sys.path.append(pacPath+"/lib/libs")
                         
addscripts()      


from iTools import printD,printE
if Params.startswith("'file_"):
         Params=Params.replace("'","").replace('"','')       
         filename=Params.split(",")[0]
         index=int(Params.split(",")[1])
         jfile=os.path.join(appPath+"/tmp/"+filename+".json")
         sys.argv=[]

         try:
             
             with io.open(jfile, 'r', encoding="utf8") as json_file:
                jdata = json.load(json_file)
                cParams=jdata[index]
               
                try:
                   name=cParams['name']
                   cParams.update({'name':name.encode("utf-8")})
                except:
                        
                                   pass

                try:
                   desc=cParams['desc']
                   cParams.update({'desc':desc.encode("utf-8")})
                except:
                                   pass
                try:
                   url=cParams['Url']
                   cParams.update({'Url':url.encode("utf-8")})
                except:
                                   pass

                try:
                   url=cParams['url']
                   cParams.update({'url':url.encode("utf-8")})
                except:
                                   pass 

                                
                sys.argv=[]
                sys.argv.append(__file__)
                sys.argv.append("1")
                sys.argv.append(cParams)
              
         except:
              printE()
              print "wsyspath>>-failed to get json params,check error<<"
else:
            params=sys.argv[2][1:-1]
            cParams=ast.literal_eval(params)
                 
            sys.argv=[]
            
            
            image=cParams.get('icon',"")
            cParams.update({"icon":image})
            sys.argv.append(__file__)
            sys.argv.append("1")
            sys.argv.append(cParams) 
try:

       
        
        try:
          marker="***********************input cParams***************************\n"          
      
          printD(marker,cParams)
          from default import start
          datalist=start(cParams)
    
          dataFile=os.path.join(appPath+"/tmp/data.txt")
          if os.path.exists(dataFile):
                  os.remove(dataFile)
          dataFile=os.path.join(appPath+'/tmp/data.json')
          if datalist==[]:
                print "No data returned"
          else:      
              
              with open(dataFile, 'w') as outfile:
                    json.dump(datalist, outfile)
        except Exception as error:
              printE()
              print "Error:", str(error)
except Exception as error:
        trace_error()
        print "error",str(error)
