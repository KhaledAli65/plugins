# -*- coding: utf-8 -*-
from iTools import CBaseAddonClass
self = CBaseAddonClass()
import requests
import re
Sgn = requests.Session()
def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except:
        return ""
def find_multiple_matches(text, pattern):
    return re.findall(pattern, text, re.DOTALL)
def get_M3u(url):
    Mlist = []
    html = self.getPage(url)
    print "bentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibentibenti",html
    if html:
        _srcs = re.findall(r'#EXT-X-STREAM-INF:PROGRAM-ID=1,.+?RESOLUTION=(.+?),.+?http(.+?).m3u8', html,re.S)
        if _srcs:
            for qlt,href in _srcs:
                qlt = qlt.split('x')[1]+"p"
                href=href.replace('\n','')
                href="http"+href+".m3u8"
                Mlist.append((qlt,href))
            return Mlist
        else:return 'nada'
    else:return 'nada'
def get_video_url(url):
    Infos = ''
    url = url.replace('\n','')
    video_urls = []
    data=self.getPage(url)#Sgn.get(url).content#
    #print "////////////////////////////////",data
    rgx = 'sources:.\[.*?]'
    _dat = find_single_match(data, 'sources: \[.*?\]')
    matches = find_multiple_matches(_dat, '(http.*?)"')
    #print "=====================================================================",_dat
    if matches:
        for x in matches:
            if '.m3u8' in x:
                links = get_M3u(x)
                if links!='nada':
                    for x in links:
                        w = ('Cool_* vidlox ['+x[0]+']',x[1])
                        video_urls.append(w)
                else:
                    w = ('Cool_* vidlox',x)
                    video_urls.append(w)
            else:
                w = ('Cool_* vidlox',x)
                video_urls.append(w)
    else:
        w = ('Ooops_* vidlox','http://error')
        video_urls.append(w)
    return video_urls
if __name__=='__main__':
    url0='https://vidlox.me/embed-d75b2c21zbpn'
    print get_video_url(url0)