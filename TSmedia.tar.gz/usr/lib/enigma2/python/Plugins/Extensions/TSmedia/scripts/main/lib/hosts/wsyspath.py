import os,sys

appPath=os.path.split(__file__)[0].split("scripts")[0]

def addscripts():

        scriptsPath =os.path.join(appPath,"scripts")
                   
             
        for name in os.listdir(scriptsPath):
                       if not os.path.isfile(name):
                          pacPath=os.path.join(scriptsPath,name)
                          sys.path.append(pacPath+"/lib")
                          for subname in os.listdir(pacPath+"/lib"):
                              if not os.path.isfile(subname):
                                  sys.path.append(pacPath+"/lib"+"/"+subname)


addscripts()


 
