import requests,re,json
St = requests.Session()
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
hdr = {'Host': 'apiv2.gofile.io',
       'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
       'Accept': '*/*',
       'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
       'Accept-Encoding': 'gzip, deflate',
       'Origin': 'https://gofile.io',
       'Connection': 'keep-alive',
       'Referer': 'https://gofile.io/d/5K4k5Z?D52C8098-9373-4E43-B2B3-959B756C417E_kis_cup_B2E7DBCB_5BD4_4A23_86A9_329C9410AC8F_WycMGRwGE1U2UjslKRVTPut6MXFOPVHvfTdi',
       'TE': 'Trailers'}
def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except:
        return ""
def get_video_url(uri):
    _id = ''
    if '?' in uri:
        _id=uri.split('?')[0]
        _id=_id.split('/')[-1]
    else:
        _id=uri.split('/')[-1]
    url = 'https://apiv2.gofile.io/getUpload?c='+str(_id)
    video_urls = []
    sourc,r,Src = '','',''
    hdr.update({'Referer':uri})
    try:r = St.get(url,headers=hdr,verify=False).json()
    except:r=''
    if r!='':
        data = r['data']
        sourc = data['files']
        for keys in sourc:
            Src =sourc[keys]['link']
        if Src:
            video_urls.append(('Cool_gofile',Src))
        else:video_urls.append(('Ooops_gofile','http://Error'))
    else:video_urls.append(('Ooops_gofile','http://Error'))
    return video_urls

if __name__=='__main__':
    url0='https://gofile.io/d/5K4k5Z'
    print get_video_url(url0)
