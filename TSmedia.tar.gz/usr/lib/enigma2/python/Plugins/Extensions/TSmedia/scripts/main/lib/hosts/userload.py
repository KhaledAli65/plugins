#!/usr/bin/python
# -*- coding: utf-8 -*-
print "MARHABA__MARHABA__MARHABA__MARHABA__MARHABA__MARHABA__MARHABA__MARHABA__MARHABA__MARHABA__"
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
import re,requests,jsunpack,json,base64,js2py
St = requests.Session()
def decode(text):
    text = re.sub(r"\s+|/\*.*?\*/", "", text)
    data = text.split("+(ﾟДﾟ)[ﾟoﾟ]")[1]
    chars = data.split("+(ﾟДﾟ)[ﾟεﾟ]+")[1:]
    txt = ""
    for char in chars:
        char = char \
            .replace("(oﾟｰﾟo)","u") \
            .replace("c", "0") \
            .replace("(ﾟДﾟ)['0']", "c") \
            .replace("ﾟΘﾟ", "1") \
            .replace("!+[]", "1") \
            .replace("-~", "1+") \
            .replace("o", "3") \
            .replace("_", "3") \
            .replace("ﾟｰﾟ", "4") \
            .replace("(+", "(")
        char = re.sub(r'\((\d)\)', r'\1', char)
        c = ""; subchar = ""
        for v in char:
            c+= v
            try: x = c; subchar+= str(eval(x)); c = ""
            except: pass
        if subchar != '': txt+= subchar + "|"
    txt = txt[:-1].replace('+','')
    txt_result = "".join([ chr(int(n, 8)) for n in txt.split('|') ])
    print '_________',txt_result+'__________________'
    return toStringCases(txt_result)
def toStringCases(txt_result):
    sum_base = ""
    m3 = False
    if ".toString(" in txt_result:
        if "+(" in  txt_result:
            m3 = True
            sum_base = "+"+find_single_match(txt_result,".toString...(\d+).")
            txt_pre_temp = find_multiple_matches(txt_result,"..(\d),(\d+).")
            txt_temp = [ (n, b) for b ,n in txt_pre_temp ]
        else:
            txt_temp = find_multiple_matches(txt_result, '(\d+)\.0.\w+.([^\)]+).')
        for numero, base in txt_temp:
            code = toString( int(numero), eval(base+sum_base) )
            if m3:
                txt_result = re.sub( r'"|\+', '', txt_result.replace("("+base+","+numero+")", code) )
            else:
                txt_result = re.sub( r"'|\+", '', txt_result.replace(numero+".0.toString("+base+")", code) )
    return txt_result
def toString(number,base):
    string = "0123456789abcdefghijklmnopqrstuvwxyz"
    if number < base:
        return string[number]
    else:
        return toString(number//base,base) + string[number%base]
def get_eval(s):
    _eval = ''
    _Cas = False
    _eval = re.findall('''eval\(function(.+?)</script>''',s,re.S)
    if _eval:
        _eval=_eval
    else:
        _eval=re.findall('''eval\(function(.+?)</script>''',s)
    if _eval:
        _Cas = jsunpack.unpack(_eval[0])
    if _Cas:
        return _Cas
    else:
        return 'Prblm_Eval'
def get_video_url(url):
    key_1 = ''
    key_2 = ''
    morocco = ''
    mycountry = ''
    urlapi = "https://userload.co/api/assets/userload/js/videojs.js"   
    List = []
    _id = url.split('/')[-1]
    r = St.get(urlapi).content
    regx = '(ﾟωﾟ.+?\(\'_\'\);)'
    charabia_1 = re.findall(regx,r)
    result = decode(charabia_1[0])
    regx1 =  'morocco=".([^\W]+).+?"&mycountry=".([^\W]+)'
    aResult_2 = re.findall(regx1,result)
    key_1 = aResult_2[0][0]
    key_2 = aResult_2[0][1]
    _r = St.get(url).content
    aResult_3 = get_eval(_r)
    regx2 = 'var\s(.+?)="([^"]*)'
    aResult_4 = re.findall(regx2,aResult_3)
    for r in aResult_4:
        if r[0] == key_1:
            morocco = r[1]
        if r[0] == key_2:
            mycountry = r[1]
    if morocco and mycountry:
        url2 = 'https://userload.co/api/request/'
        Prm = {'morocco': morocco,'mycountry':mycountry}
        hdr = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
               'Content-Type': 'application/x-www-form-urlencoded',
               'Connection': 'keep-alive',
               'Referer': url}
        _dat = St.post(url2,headers=hdr,data=Prm).content
        if _dat:
            w = ('Cool_userload',_dat)
            List.append(w)
        else:
            w = ('Ooops_userload','http://error')
            List.append(w)
    else:
        w = ('Ooops_userload','http://error')
        List.append(w)
    return List
if __name__=='__main__':
    url0='https://userload.co/embed/df68297d29da'
    print get_video_url(url0)