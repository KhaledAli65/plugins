import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
import re,time
import requests
from requests.auth import HTTPBasicAuth
import urllib
import requests,re,base64,urllib
S = requests.Session()
def decodeur1(Html):
    from ast import literal_eval
    vl = re.search('var *(_\w+) *= *(\[[^;]+\]);', Html, re.DOTALL)
    if vl:
        var_name = vl.group(1)
        list_b64 = vl.group(2)
        start = Html.find(list_b64)
        Html = Html[start:]
        list_b64 = literal_eval(list_b64)
        nrvr = re.search(var_name + ',(0x\w+)\)*; *var *([^=]+) *=', Html, re.DOTALL)
        if nrvr:
            number_ref = int(nrvr.group(1),16)
            var_ref = nrvr.group(2)
            i = 0
            while i < number_ref:
                list_b64.append(list_b64.pop(0))
                i += 1
            test2 = re.findall("(?:;|;}\(\)\);)sources(.+?)};", Html, re.DOTALL)
            if test2:
                url = ''
                movieID = ''
                qua_list = set()
                lang_list = list()
                supportedLang = ['eng', 'eng2', 'eng3', 'eng4', 'English', 'fre', 'fre1', 'fre2', 'French',
                                 'jap', 'jpn', 'Japanese', 'chi', 'Chinese', 'rus',
                                 'Russian', 'spa', 'Spanish', 'ger', 'ger2', 'German']
                for page in test2:
                    tableau = {}
                    data = page.find("={")
                    if data != -1:
                        Html = page[data:]
                        if Html:
                            i = 0
                            vname = ''
                            for i in xrange(len(Html)):
                                fisrt_r = re.match("([^']+)':", Html)
                                if fisrt_r:
                                    vname = fisrt_r.group(1)
                                    tableau[vname] = 'null'
                                    index = len(fisrt_r.group()[:-1])
                                    Html = Html[index:]
                                whats = re.match("[:+]'([^']+)'", Html, re.DOTALL)
                                if whats:
                                    if vname:
                                        ln = tableau[vname]
                                        if not ln == 'null':
                                            tableau[vname] = tableau[vname] + whats.group(1)
                                        else:
                                            tableau[vname] = whats.group(1)
                                    index = len(whats.group(0))
                                    Html = Html[index:]
                                else:
                                    whats = re.match("\+*" + var_ref + "\(\'([^']+)\' *, *\'([^']+)\'\)", Html, re.DOTALL)
                                    if whats:
                                        if vname:
                                            ln = tableau[vname]
                                            if not ln == 'null':
                                                tableau[vname] = tableau[vname] + decoder(list_b64[int(whats.group(1), 16)], whats.group(2))
                                            else:
                                                tableau[vname] = decoder(list_b64[int(whats.group(1), 16)], whats.group(2))
                                        index = len(whats.group(0))
                                        Html = Html[index:]
                                if not whats:
                                    Html = Html[1:]
                        if tableau:
                            langFound = False
                            for i, j in tableau.items():
                                if j == 'null':
                                    continue
                                if j.startswith('http') and j.endswith('com'):  # url
                                    url = tableau[i] if not tableau[i] in url else url
                                    continue
                                if len(i) == 5 and len(j) >= 10 and j.isalnum() and not 'video' in j:
                                    movieID = j if not j in movieID else movieID
                                    continue
                                if not langFound and len(test2) > 1:  # s il y a plusieurs flux
                                    if j in supportedLang:
                                        if not j in lang_list:  # Preserve l ordre et l'unicite
                                            lang_list.append(j)
                                        langFound = True
                                        continue
                                if j == '360' or j == '480' or j == '720' or j == '1080' or j == '2160':
                                    qua_list.add(j)
                                elif j == '360p' or j == '480p' or j == '720p' or j == '1080p' or j == '2160p':
                                    qua_list.add(j[:-1])
                if len(lang_list) == 0:
                    lang_list.append('NONE')
                url_list = []
                ql_list = []
                for qual in sorted(qua_list):
                    idxLang = 0
                    for lang in lang_list:
                        url_list.append("{}/{}/{}/{}/video.mp4".format(url, movieID, qual, idxLang))
                        ql = qual
                        if not 'NONE' in lang:
                            ql += ' [' + lang[:3].upper() + ']'
                        ql_list.append(ql) 
                        idxLang += 1
                return ql_list, url_list
def decoder(data, fn):
    data = base64.b64decode(data)
    secretKey = {}
    url = ''
    temp = ''
    tempData = ''
    for i in xrange(len(data)):
        tempData += ("%" + format(ord(data[i]), '02x'))
    data = urllib.unquote(tempData)
    x = 0
    while x < 256:
        secretKey[x] = x
        x += 1
    y = 0
    x = 0
    while x < 256:
        y = (y + secretKey[x] + ord(fn[x % len(fn)])) % 256
        temp = secretKey[x]
        secretKey[x] = secretKey[y]
        secretKey[y] = temp
        x += 1
    x = 0
    y = 0
    i = 0
    data = data.decode('utf-8')
    while i < len(data):
        x = (x + 1) % 256
        y = (y + secretKey[x]) % 256
        temp = secretKey[x]
        secretKey[x] = secretKey[y]
        secretKey[y] = temp
        url += (chr(ord(data[i]) ^ secretKey[(secretKey[x] + secretKey[y]) % 256]))
        i += 1
    return url
def ChangFormurl(url):##Modfd 5/02/2021
    if '?Key=' in url:
        url=url.split('/?Key=')[0]
    return url.split('/')[-1]
def get_video_url(url):
    _UrlVideo = []
    s = requests.Session()
    url = url.replace('uptostream','uptobox')
    _Url= "https://uptostream.com/api/streaming/source/get?token=null&file_code={}".format(ChangFormurl(url))
    print "_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url_Url------------------",_Url
    _r = s.get(_Url,verify=False).content
    print "*******************************************************************************************",_r
    qua, url_list = decodeur1(_r)
    if url_list:
        list(set(url_list))
        print "TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT",url_list
        for link in url_list:
            link = link.replace('\\','')
            w=('Cool_uptostream',link)
            _UrlVideo.append(w)
    else:
        w=('Ooops_uptostream','http://error')
        _UrlVideo.append(w)
    print '****_UrlVideo',_UrlVideo    
    return _UrlVideo
if __name__=='__main__':
    url0='https://uptostream.com/iframe/9fsesfsoolrw'
    print get_video_url(url0)
