import requests,re,js2py,time
St = requests.Session()
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
hdr = {'Host': 'vidcloud.pro',
       'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
       'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
       'Accept-Encoding': 'gzip, deflate',
       'Connection': 'keep-alive',
       'Upgrade-Insecure-Requests': '1'}
def find_single_match(data, patron, index=0):
    try:
        matches = re.findall(patron, data, flags=re.DOTALL)
        return matches[index]
    except:
        return ""
def get_video_url(uri):
    video_urls = []
    sourc,r = '',''
    try:r = St.get(uri,headers=hdr,verify=False).content
    except:r=''
    regx = 'sources = \[\{"file":"(.+?)"'
    if r!='':
        sourc = re.findall(regx,r)
        if sourc:
            sourc = sourc[0].replace('\\','')
            video_urls.append(('Cool_vidcloud',sourc))
        else:video_urls.append(('Ooops_vidcloud','http://Error'))
    else:video_urls.append(('Ooops_vidcloud','http://Error'))
    return video_urls

if __name__=='__main__':
    url0='https://vidcloud.pro/embed5/b02jgoj54wcul?i=eefe8d9356bd959ed885c9262755c8f7&el=4071475'
    print get_video_url(url0)
