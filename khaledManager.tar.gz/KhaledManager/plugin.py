from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.FileList import FileList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Screens.InputBox import InputBox
from Tools.LoadPixmap import LoadPixmap
from Screens.InfoBar import MoviePlayer
from ServiceReference import ServiceReference 
import os
import shutil

# System Paths
BUILD_ROOT = "/media/hdd/ipk_build"

# --- THE TEXT EDITOR ENGINE ---
class KhaledTextEditor(Screen):
    skin = """
    <screen name="KhaledTextEditor" position="center,center" size="900,600" title="Khaled Text Editor">
        <widget name="text_display" position="10,10" size="880,500" font="Regular;22" halign="left" valign="top" />
        <ePixmap pixmap="buttons/red.png" position="250,530" size="150,40" alphatest="on" />
        <widget name="key_red" position="250,530" size="150,40" zPosition="1" font="Regular;20" halign="center" valign="center" transparent="1" />
        <ePixmap pixmap="buttons/green.png" position="450,530" size="150,40" alphatest="on" />
        <widget name="key_green" position="450,530" size="150,40" zPosition="1" font="Regular;20" halign="center" valign="center" transparent="1" />
    </screen>"""

    def __init__(self, session, filepath):
        Screen.__init__(self, session)
        self.filepath = filepath
        self.content = ""
        try:
            with open(filepath, 'r') as f:
                self.content = f.read()
        except Exception as e:
            self.content = "Error reading file: %s" % str(e)
        
        self["text_display"] = Label(self.content)
        self["key_red"] = Label("Cancel")
        self["key_green"] = Label("Edit & Save")
        self["actions"] = ActionMap(["ColorActions", "SetupActions"], {
            "red": self.close,
            "green": self.triggerKeyboard,
            "cancel": self.close
        }, -1)

    def triggerKeyboard(self):
        # Open virtual keyboard with current content
        self.session.openWithCallback(self.saveChanges, InputBox, title="Edit Content:", text=self.content, type=InputBox.TYPE_TEXT)

    def saveChanges(self, new_text):
        if new_text is not None:
            try:
                # 1. Create .bak revision
                bak_path = self.filepath + ".bak"
                shutil.copy2(self.filepath, bak_path)
                # 2. Save new content
                with open(self.filepath, 'w') as f:
                    f.write(new_text)
                self.session.open(MessageBox, "File Saved Successfully!\nBackup: %s" % os.path.basename(bak_path), MessageBox.TYPE_INFO)
                self.close()
            except Exception as e:
                self.session.open(MessageBox, "Save Failed: %s" % str(e), MessageBox.TYPE_ERROR)

# --- THE MAIN MANAGER ---
class KhaledUltraManager(Screen):
    skin = """
    <screen name="KhaledUltraManager" position="center,center" size="1000,650" title="Khaled Pro Manager">
        <widget name="filelist" position="10,10" size="580,520" scrollbarMode="showOnDemand" />
        <widget name="preview" position="610,110" size="360,280" alphatest="on" />
        <widget name="file_info" position="610,400" size="360,100" font="Regular;20" halign="center" />
        
        <ePixmap pixmap="buttons/red.png" position="10,580" size="150,40" alphatest="on" />
        <widget name="key_red" position="10,580" size="150,40" zPosition="1" font="Regular;22" halign="center" valign="center" transparent="1" />
        <ePixmap pixmap="buttons/green.png" position="170,580" size="150,40" alphatest="on" />
        <widget name="key_green" position="170,580" size="150,40" zPosition="1" font="Regular;22" halign="center" valign="center" transparent="1" />
        <ePixmap pixmap="buttons/yellow.png" position="330,580" size="150,40" alphatest="on" />
        <widget name="key_yellow" position="330,580" size="150,40" zPosition="1" font="Regular;22" halign="center" valign="center" transparent="1" />
        <ePixmap pixmap="buttons/blue.png" position="490,580" size="150,40" alphatest="on" />
        <widget name="key_blue" position="490,580" size="150,40" zPosition="1" font="Regular;22" halign="center" valign="center" transparent="1" />
        <ePixmap pixmap="buttons/key_info.png" position="650,580" size="150,40" alphatest="on" />
        <widget name="key_info" position="650,580" size="150,40" zPosition="1" font="Regular;22" halign="center" valign="center" transparent="1" />
        <ePixmap pixmap="buttons/key_menu.png" position="810,580" size="150,40" alphatest="on" />
        <widget name="key_menu" position="810,580" size="150,40" zPosition="1" font="Regular;22" halign="center" valign="center" transparent="1" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self["filelist"] = FileList("/media/hdd/", showMountpoints=True, showDirectories=True, showFiles=True)
        self["preview"] = Pixmap()
        self["file_info"] = Label("Select a File")
        
        self["key_red"] = Label("Exit")
        self["key_green"] = Label("Extract")
        self["key_yellow"] = Label("Install")
        self["key_blue"] = Label("Run .sh")
        self["key_info"] = Label("Search")
        self["key_menu"] = Label("Menu")

        self["actions"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions", "MenuActions"],
        {
            "ok": self.handleOK,
            "cancel": self.close,
            "up": self.up, "down": self.down,
            "red": self.close,
            "green": self.extractFile,
            "yellow": self.installIPK,
            "blue": self.runSelectedScript,
            "info": self.searchFile,
            "menu": self.openMenu
        }, -1)

    def up(self): self["filelist"].up(); self.updatePreview()
    def down(self): self["filelist"].down(); self.updatePreview()

    def handleOK(self):
        selection = self["filelist"].getSelection()
        if selection and selection[1]: # Directory
            self["filelist"].changeDir(selection[0])
        else: # File
            filename = self["filelist"].getFilename()
            if filename:
                ext = filename.lower()
                if ext.endswith((".txt", ".py", ".xml", ".sh", ".conf", ".list", ".php", ".html")):
                    self.session.open(KhaledTextEditor, filename)
                elif ext.endswith((".mp4", ".mkv", ".ts")):
                    self.session.open(MoviePlayer, ServiceReference(4097, 0, filename))

    def updatePreview(self):
        filename = self["filelist"].getFilename()
        if filename and (filename.endswith(".png") or filename.endswith(".jpg")):
            self["preview"].instance.setPixmap(LoadPixmap(path=filename))
        else: self["preview"].instance.setPixmap(None)
        self["file_info"].setText(os.path.basename(filename) if filename else "")

    def openMenu(self):
        from Screens.ChoiceBox import ChoiceBox
        menu = [
            ("copy", "Copy (File/Folder)"),
            ("delete", "Delete Selected"),
            ("archive", "Archive Selection"),
            ("chmod", "Chmod 755"),
            ("rename", "Rename"),
            ("mkdir", "New Folder")
        ]
        if self.copied_source: menu.insert(1, ("paste", "Paste Here"))
        self.session.openWithCallback(self.menuCallback, ChoiceBox, title="Advanced Options", list=menu)

    def menuCallback(self, ret):
        if not ret: return
        if ret[0] == "archive": self.openArchiveFormatMenu()
        elif ret[0] == "copy": self.copied_source = self["filelist"].getSelection()[0]
        elif ret[0] == "paste": self.pasteRecursive()
        elif ret[0] == "delete": self.deleteRequest()
        elif ret[0] == "chmod": 
            os.system("chmod 755 '%s'" % self["filelist"].getSelection()[0])
            self.session.open(MessageBox, "Permissions Fixed!", MessageBox.TYPE_INFO)

    # --- REPAIRED ARCHIVE LOGIC ---
    def openArchiveFormatMenu(self):
        from Screens.ChoiceBox import ChoiceBox
        formats = [("zip", ".zip"), ("tar.gz", ".tar.gz"), ("tar.xz", ".tar.xz")]
        self.session.openWithCallback(self.getArchiveName, ChoiceBox, title="Format:", list=formats)

    def getArchiveName(self, val):
        if val:
            self.selected_format = val[0]
            curr_selection = self["filelist"].getSelection()[0]
            # Clean name for the input box
            default_name = os.path.basename(curr_selection.rstrip('/'))
            self.session.openWithCallback(self.doArchive, InputBox, title="Archive Name:", text=default_name, type=InputBox.TYPE_TEXT)

    def doArchive(self, name):
        if name:
            source = self["filelist"].getSelection()[0]
            parent = os.path.dirname(source.rstrip('/'))
            target_name = name + "." + self.selected_format
            base_item = os.path.basename(source.rstrip('/'))
            
            # Using quotes to fix "nothing happens" error with spaces
            if self.selected_format == "zip":
                cmd = "cd '%s' && zip -r '%s' '%s'" % (parent, target_name, base_item)
            else:
                cmd = "tar -czvf '%s/%s' -C '%s' '%s'" % (parent, target_name, parent, base_item)
            
            self.session.open(Console, title="Creating Archive...", cmdlist=[cmd])
            self["filelist"].refresh()

    def pasteRecursive(self):
        dest = os.path.join(self["filelist"].getCurrentDirectory(), os.path.basename(self.copied_source))
        if os.path.isdir(self.copied_source): shutil.copytree(self.copied_source, dest)
        else: shutil.copy2(self.copied_source, dest)
        self["filelist"].refresh()

    def deleteRequest(self):
        fn = self["filelist"].getSelection()[0]
        self.session.openWithCallback(self.deleteConfirmed, MessageBox, "Delete: %s?" % fn, MessageBox.TYPE_YESNO)

    def deleteConfirmed(self, res):
        if res:
            fn = self["filelist"].getSelection()[0]
            if os.path.isdir(fn): shutil.rmtree(fn)
            else: os.remove(fn)
            self["filelist"].refresh()

    def extractFile(self):
        fn = self["filelist"].getFilename()
        if fn.endswith(".zip"): cmd = "unzip -o '%s' -d '%s'" % (fn, self["filelist"].getCurrentDirectory())
        else: cmd = "tar -xvf '%s' -C '%s'" % (fn, self["filelist"].getCurrentDirectory())
        self.session.open(Console, cmdlist=[cmd])

    def installIPK(self):
        fn = self["filelist"].getFilename()
        if fn.endswith(".ipk"): self.session.open(Console, cmdlist=["opkg install '%s'" % fn])

    def runSelectedScript(self):
        fn = self["filelist"].getFilename()
        if fn.endswith(".sh"): self.session.open(Console, cmdlist=["chmod 755 '%s' && '%s'" % (fn, fn)])

    def searchFile(self):
        self.session.openWithCallback(self.searchDone, InputBox, title="Search:", type=InputBox.TYPE_TEXT)
    def searchDone(self, text):
        if text: self.session.open(Console, cmdlist=["find %s -name '*%s*'" % (self["filelist"].getCurrentDirectory(), text)])

def main(session, **kwargs): session.open(KhaledUltraManager)
def Plugins(**kwargs):
    return [PluginDescriptor(name="Khaled Pro Manager", description="Editor & Archiver", where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)]

