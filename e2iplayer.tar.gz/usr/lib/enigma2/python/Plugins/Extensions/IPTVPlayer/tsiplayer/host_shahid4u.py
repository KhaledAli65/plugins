# -*- coding: utf-8 -*-
import re

from Plugins.Extensions.IPTVPlayer.libs import ph
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG
from Plugins.Extensions.IPTVPlayer.tsiplayer.libs.tstools import (
    TSCBaseHostClass, tshost)


def getinfo():
    info_={}
    name='Shahid4u'
    hst = 'https://s1.shahidpro.net'
    info_['old_host'] = hst
    hst_ = tshost(name)
    if hst_!='': hst = hst_
    info_['host']= hst
    info_['name']=name
    info_['version']='2.1 18/07/2022'
    info_['dev']='Tsiplayer'
    info_['cat_id']='21'
    info_['desc']='أفلام و مسلسلات عربية و اجنبية'
    info_['icon']='https://i.ibb.co/PCjC1WF/Shahid4u.png'
    info_['recherche_all']='1'
    #info_['update']='change to ww.shahid4u.net'

    return info_

class TSIPHost(TSCBaseHostClass):

    def __init__(self):
        TSCBaseHostClass.__init__(self,{})
        self.MAIN_URL = getinfo()['host']

    def showmenu(self,cItem):
        TAB = [('افلام','','10',0),('مسلسلات','','10',1),('عروض مصارعة','/genre/عروض-المصارعة-الحرة/','20','')]
        self.add_menu(cItem,'','','','','',TAB=TAB,search=True)

    def showfilter(self,cItem):
        count=cItem.get('count',1)
        data1=cItem.get('data','none')
        codeold=cItem.get('code',self.MAIN_URL+'/getposts?')
        if count==1:
            sts, data = self.getPage(self.MAIN_URL)
            if sts:
                data1=re.findall('dropdown select-menu">.*?<ul(.*?)</ul>', data, re.S)
            else:
                data1=''
        if count==4:
            mode_='20'
        else:
            mode_='19'
        lst_data1 = re.findall('<li.*?data-tax="(.*?)".*?data-cat="(.*?)".*?bold">(.*?)<',data1[count-1], re.S)
        for (x1,x2,x3) in lst_data1:
            code=codeold+x1+'='+x2+'&'
            self.addDir({'import':cItem['import'],'category' :'host2', 'url':code, 'title':x3, 'desc':x1, 'icon':cItem['icon'], 'mode':mode_,'count':count+1,'data':data1,'code':code, 'sub_mode':'item_filter','page':-1})

    def showmenu1(self,cItem):
        self.add_menu(cItem,'<ul class="sub-menu">(.*?)</ul','<li.*?href="(.*?)".*?>(.*?)<','','20',ind_0=cItem['sub_mode'],del_titre='افلام للكبار فقط')

    def showitms(self,cItem):
        desc = [('Genre','class="genres">(.*?)</div>','',''),('IMDB','rate ti-star">(.*?)</span>','',''),('Quality','class="quality".*?>(.*?)</span>','','')]
        next = ['<link rel="next".*?href="(.*?)"','20']
        self.add_menu(cItem,'','class="poster">.*?data-src="(.*?)".*?alt="(.*?)">.*?">(.*?)</div>.*?href="(.*?)">','','21',ord=[3,1,0,3],Desc=desc,Next=next,u_titre=True,EPG=True)

    def showelms(self,cItem):
        desc = [('Story','class="wp-content">(.*?)<div id="','','')]
        if "tvshows" in cItem['url']:
            URL = cItem.get('url','')
            sts, data = self.getPage(URL)
            if sts:
                Liste_els = re.findall('class="episodiotitle">.*?href="(.*?)">(.*?)</a>', data, re.S)
                if Liste_els:
                    for (url,titre) in Liste_els:
                        self.addVideo({'import':cItem['import'],'category' : 'host2','title':titre,'url':url ,'desc':cItem['desc'],'icon':cItem['icon'],'good_for_fav':True,'hst':'tshost'})
        else:
            self.addVideo({'import':cItem['import'], 'hst':'tshost', 'url':cItem['url'], 'title':'--> '+cItem['title']+' <--', 'desc':cItem['desc'], 'icon':cItem['icon']})
            self.add_menu(cItem,'','class="episode-block">.*?href="(.*?)".*?title="(.*?)".*?(?:src="|image=")(.*?)"','','video',ord=[0,1,2],u_titre=True,EPG=True,Desc=desc,add_vid=False)
            self.add_menu(cItem,'tab-class" id="seasons">(.*?)<div class="tags','content-box">.*?href="(.*?)".*?title="(.*?)".*?image="(.*?)"','','21',ord=[0,1,2],Titre='Seasons',u_titre=False,EPG=True)


    def SearchResult(self,str_ch,page,extra):
        url = self.MAIN_URL+'/page/'+str(page)+'/?s='+str_ch
        desc = [('Genre','class="genres">(.*?)</div>','',''),('IMDB','rate ti-star">(.*?)</span>','',''),('Quality','class="quality".*?>(.*?)</span>','','')]
        self.add_menu({'import':extra,'url':url},'','class="content-box">.*?href="(.*?)".*?title="(.*?)".*?data-image="(.*?)".*?<(.*?)</h3>','','21',ord=[0,1,2,3],Desc=desc,u_titre=True,EPG=True)


    def get_links(self,cItem):
        urlTab = []
        URL=cItem['url']
        sts, data = self.getPage(URL)
        if sts:
            server_data = re.findall('class="dooplay_player">(.*?)sheader">', data, re.S)
            if server_data:
                code_data = re.findall('</div>.*?<div id="(.*?)" class.*?data-litespeed-src="(.*?)"', server_data[0], re.S)
                for (titre_,url_) in code_data:
                    titre = self.cleanHtmlStr(titre_).strip()
                    if 'single' in titre or 'advc-menu' in titre:
                        titre = '|Server 01|'
                    elif 'source-player-2' in titre:
                        titre = '|Server 02|'
                    elif 'source-player-3' in titre:
                        titre = '|Server 03|'
                    urlTab.append({'name':titre, 'url':url_,'need_resolve':1,'type':''})
        return urlTab

    def getArticle(self, cItem):
        printDBG("Arablionz.getVideoLinks [%s]" % cItem)
        otherInfo1 = {}
        desc = cItem['desc']
        sts, data = self.getPage(cItem['url'])
        if sts:
            lst_dat=re.findall('class="half-tags">.*?<li>(.*?)</li>(.*?)</ul>', data, re.S)
            for (x1,x2) in lst_dat:
                if 'الجودة' in x1: otherInfo1['quality'] = ph.clean_html(x2)
                if 'السنة' in x1: otherInfo1['year'] = ph.clean_html(x2)
                if 'النوع' in x1: otherInfo1['genres'] = ph.clean_html(x2)
                if 'ممثلين' in x1: otherInfo1['actors'] = ph.clean_html(x2)
                if 'القسم' in x1: otherInfo1['category'] = ph.clean_html(x2)
                if 'مخرج' in x1: otherInfo1['director'] = ph.clean_html(x2)
                if 'لمؤلف' in x1: otherInfo1['writer'] = ph.clean_html(x2)
            lst_dat0=re.findall('post-story">(.*?)</div>', data, re.S)
            if lst_dat0: desc = ph.clean_html(lst_dat0[0])
            else: desc = cItem['desc']
        icon = cItem.get('icon')
        title = cItem['title']
        return [{'title':title, 'text': desc, 'images':[{'title':'', 'url':icon}], 'other_info':otherInfo1}]


