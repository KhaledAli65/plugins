#!/usr/bin/python
# -*- coding: utf-8 -*-
################################### RADIO #################################################
import xml.etree.ElementTree as ET
from xml.etree.ElementTree import ElementTree
PATH_Xml = '/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/XML/Radion.xml'
###########################################################################################
import requests,re,json,os
St = requests.Session()
###########################################################################################
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore',InsecureRequestWarning)
###########################################################################################
from Components.Pixmap import Pixmap
from Components.Label import Label
from Tools.Directories import fileExists
from enigma import ePicLoad, gPixmapPtr
from enigma import eTimer
###########################################################################################
MyListeMaim = {'1':'https://www.mp3quran.net','2':'https://suratmp3.com','3':'http://www.coran-en-ligne.com/coran-en-arabe.html'}
from Plugins.Extensions.Ansite.Adons.Compmt.Config import show_mp3quran,show_mp3quranAudio
##############################################اضافة ملف تحميل الصور
import os,shutil
Fold = '/media/hdd'
Fold_0 = '/media/hdd/imagesAnsite_1'
Fold_1 = "/tmp/imagesAnsite_1"
if os.path.exists(Fold) and os.path.ismount(Fold):
    if os.path.exists(Fold_0):
        MyFolder = True
    else:
        os.mkdir(Fold_0)
        MyFolder = True
else:
    if os.path.exists(Fold_1):
        MyFolder = False
    else:
        os.mkdir(Fold_1)
        MyFolder = False
##############################################تحديد طبيعة الصورة المستعملة
if os.path.exists('/var/lib/dpkg/status'):
    enigmaos = 'oe2.2'
else:
    enigmaos = 'oe2.0'
def get_PathImg():#
    path = ''
    if MyFolder:path=Fold_0+'/'
    else:path=Fold_1+'/'
    return path
##############################################جلب بيانات ملف تحميل الصور
def get_Taille(folder):
    folder_size = 0
    for (path, dirs, files) in os.walk(folder):
        for file in files:
            filename = os.path.join(path, file)
            folder_size += os.path.getsize(filename)
    Taille = "%0.1f MB" % (folder_size/(1024*1024.0))
    return str(Taille)
##############################################
MyHead = {'Host': 'equran.me',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
          'Accept-Encoding': 'gzip, deflate',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1',
          'Pragma': 'no-cache',
          'Cache-Control': 'no-cache'}
Headerso = {'Host': 'mortb.com',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
          'Accept': '*/*',
          'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
          'Accept-Encoding': 'gzip, deflate',
          'Content-type': 'application/x-www-form-urlencoded',
          'Content-Length': '60',
          'Origin': 'https://mortb.com',
          'Connection': 'keep-alive',
          'Referer': 'https://mortb.com/%D8%AD%D8%B3%D8%A7%D8%A8-%D8%A7%D9%84%D8%B9%D9%85%D8%B1-%D8%A8%D8%A7%D9%84%D9%87%D8%AC%D8%B1%D9%8A-%D9%88%D8%A7%D9%84%D9%85%D9%8A%D9%84%D8%A7%D8%AF%D9%8A/',
          'TE': 'Trailers'}
##############################################################خاص بالتاريخ الهجري ميلادي
Month = ['جانفي - يناير -',
          'فيفري - فبراير -',
          'مارس - مارس -',
          'افريل - ابريل -',
          'ماي - مايو -',
          'جوان - يونيو -',
          'جويلية - يوليو -',
          'أوت - اغسطس -',
          'سبتمبر - سبتمبر -',
          'اكتوبر - اكتوبر -',
          'نوفمبر - نوفمبر -',
          'ديسمبر - ديسمبر -']
Month_H = ['محرم',
          'صفر',
          'ربيع الأول',
          'ربيع الآخر',
          'جمادى الأولى',
          'جمادى الآخرة',
          'رجب',
          'شعبان',
          'رمضان',
          'شوال',
          'ذو القعدة',
          'ذو الحجة']
Remarq = 'يختلف عمرك بالهجري عن عمرك بالميلادي لأن السنة الهجرية 354.36 يوم بينما السنة الميلادية 365.25 يوم فهناك فرق بين التقويمين'.encode('utf-8')
Remarq1 = 'حوالي 11 يوم في كل سنة من عمرك، ولذلك فالعمر بالهجري أكبر من العمر بالميلادي وكلما كبرت زاد هذا الفرق.'.encode('utf-8')
############################################################## انتهى
class AnsiteTools():
    def __init__(self):
        ListMain = ['سورة','القرآن','القرآن 2']
        self.NbSrt = "عدد السور"
        self.SRT = "السورة رقم"
        self.Tmp = "المدة"
        self.molahada = Remarq+'\n'+Remarq1+'\n'
        self['SorateYoutu'] = Pixmap()
        self['myPicAnsite'] = Pixmap()
        self['myPicAnsiteTassafoh'] = Pixmap()
        self.timer = eTimer()
        self['url_karii'] = Label()
        for x in range(5):
            self['Pic'+str(x)] = Pixmap()
            self['myPic'+str(x)] = Pixmap()
            self['Box_'+str(x)] = Label()
        self.List_mp3audio = []
        self.ListPosition = [(128,336),(847,336),(1602,336),(128,577),(850,578),(1601,577)]
        self.List_MenuChoix = []
        self.List_MenuChoix.append(show_mp3quran('الإستماع للقرآن الكريم 1','self.session.open(Screen_MainMenu)','',''))
        self.List_MenuChoix.append(show_mp3quran('الإستماع للقرآن 2','self.session.open(Screen_MainMenu2)','',''))
        self.List_MenuChoix.append(show_mp3quran('تصفح للقرآن الكريم','self.session.open(Screen_Ansite_Tassafoh_Coran_Choix)','',''))
        self.List_MenuChoix.append(show_mp3quran('القرآن تصفحا وقراءة','self.session.open(Ansite_StreamMoshafKarii)','',''))
        self.List_MenuChoix.append(show_mp3quran('مرئيات','self.session.open(Screen_AnsiteYoutube)','',''))
        self.List_MenuChoix.append(show_mp3quran('التأريخ الهجري','self.session.open(Screen_TaarikhHijri)','',''))
        self.DayS = []
        self.DayS_H = []
        self.MonthS = []
        self.MonthS_H = []
        self.Years = []
        self.Years_H = []
        for x in range(1,32):
            self.DayS.append(show_mp3quran(str(x),'','',''))
            if x<=30:self.DayS_H.append(show_mp3quran(str(x),'','',''))
        for x in range(1,13):
            self.MonthS.append(show_mp3quran(Month[x-1],str(x),'',''))
            self.MonthS_H.append(show_mp3quran(Month_H[x-1],str(x),'',''))
        for x in range(1900,2031):
            self.Years.append(show_mp3quran(str(x),'','',''))
        self.Years.reverse()
        for x in range(1332,1453):
            self.Years_H.append(show_mp3quran(str(x),'','',''))
        self.Years_H.reverse()
        self.List_AnsiteYoutube = []
########################################جلب المقرئين#############################################################
    def mp3quran(self):
        self.List_mp3quran,Pnt = [],''
        try:self._data=St.get('http://www.mp3quran.net/ar/ajax/reads/list',timeout=10,verify=False).json()
        except:self._data=''
        if self._data!='':
            self.js_data = self._data['reads']
            if self.js_data:
                i = 0
                for keys in self.js_data:
                    print "==================================================="
                    print "karii Num__",str(i)
                    soar_count = keys['soar_count'].encode('utf-8')
                    reciter_name  = keys['reciter_name']
                    rewaya_name = keys['rewaya_name'].encode('utf-8')
                    title = keys['title'].encode('utf-8')
                    url = "https://www.mp3quran.net/ar/"+keys['slug']
                    url = url.encode('utf-8')
                    i = i + 1
                    desc = self.NbSrt.encode('utf-8')+' '+soar_count
                    self.List_mp3quran.append(show_mp3quran(title,url,rewaya_name,desc))
            else:
                self.List_mp3quran.append(show_mp3quran('للاسف مشكل في جلب البيانات','','',''))
        else:
            self.List_mp3quran.append(show_mp3quran('للاسف مشكل في الاتصال','','',''))
        return self.List_mp3quran
########################################جلب السور#############################################################
    def get_SouratUrl(self,url,name,riwaya):
        self.slug = url.split('/')[-1]
        self.Copy_Donnees(riwaya)
        self.MyDict = {}
        self.List_mp3audio = []
        self.SRT = "السورة رقم"
        self.Tmp = "المدة"
        self.name = name
        sora_audio,sora_num,sora_duration,sora_name,name1,desc='','','','','',''
        try:self.data=St.get(url,timeout=10,verify=False).content
        except:self.data=''
        if self.data!='':
            sora=re.findall('window.reciter_reads = (.+?);',self.data)
            _infos = sora[0]
            js_dat=json.loads(_infos)
            for t in range(len(js_dat)):
                rewaya_name = js_dat[t]['slug']
                if rewaya_name== self.slug:
                    self.MyDict = js_dat[t]
                    self.Write_Js(self.MyDict)
            js_dat = self.MyDict['soar']#js_dat[0]['soar']
            if js_dat:
                for keys in js_dat:
                    sora_audio = keys['sora_audio']
                    #except:sora_audio='...'
                    try:
                        sora_num = keys['sora_num']
                        # if sora_num.startswith('0'):sora_num=sora_num.replace('0','')
                        # else:sora_num=sora_num
                    except:sora_num='...'
                    try:sora_duration = keys['sora_duration']
                    except:sora_duration='...'
                    try:
                        sora_name = keys['sora_name'].encode('utf-8')
                        sora_name = sora_name.replace('\n','').replace('\r','')
                    except:sora_name='...'
                    name1 = sora_name+'  '+' بصوت '.encode('utf-8')+'  '+name.encode('utf-8')
                    kk = ' مصحف '.encode('utf-8')
                    name1 = name1.replace(kk,' ')
                    if sora_duration:
                        desc = 'سورة'.encode('utf-8')+' '+sora_name+'\n'+'القارئ'.encode('utf-8')+' '+self.name+'\n'+self.SRT.encode('utf-8')+' '+str(sora_num)+'\n'+self.Tmp.encode('utf-8')+' '+str(sora_duration)
                    else:
                        desc = 'سورة'.encode('utf-8')+' '+sora_name+'\n'+'القارئ'.encode('utf-8')+' '+self.name+'\n'+self.SRT.encode('utf-8')+' '+str(sora_num)+'\n'+self.Tmp.encode('utf-8')
                    self.List_mp3audio.append(show_mp3quranAudio(name1,sora_audio,kk,desc))
                return True,self.List_mp3audio
            else:False,self.List_mp3audio
        else:False,self.List_mp3audio
########################################جلب التاريخ الهجري#############################################################
    def get_ElyoumByLines(self):
        with open('/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/Compmt/Date.txt') as f:
            lines = f.readlines()
        DateY = lines[0].replace('\n','')
        if DateY == str(self.Get_Dates()):
            Date,Inf_1,Inf_2,Rst_hjr,Dooa = lines[0],lines[1],lines[2],lines[3],lines[4]
            return (Inf_1,Inf_2,Rst_hjr,Dooa)
        else:
            return self.get_hijri()
    def get_Elyoum(self,Inf_1,Inf_2,Rst_hjr,Dooa):
        H = str(self.Get_Dates())
        a = Inf_1.replace('\n','')
        b = Inf_2.replace('\n','')
        c = Rst_hjr.replace('\n','')
        d = Dooa.replace('\n','')
        f = '\n'
        e = H+f+a+f+b+f+c+f+d
        with open("/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/Compmt/Date.txt","wb") as file:
            file.write(e.encode())
        return H
    def get_hijri(self):
        day_hjr,month_hjr,year_hjr,Inf_1,day_grgr,month_grgr,Inf_2,Dooa,Rst_hjr = '','','','','','','','',''
        url,data = 'https://hijri-calendar.com/todaydate/',''
        try:data=St.get(url,timeout=10,verify=False).content
        except:data=''
        if data!='':
            try:
                day_hjr = re.findall('<div class="datear"><a class="dateen">اليوم</a> (.+?)</div>',data)[0]
                day_hjr = day_hjr.encode('utf-8')
            except:day_hjr=''
            try:
                month_hjr = re.findall('<div class="thename">(.+?)</div>',data)[0]
                month_hjr = month_hjr.encode('utf-8')
            except:month_hjr=''
            try:
                year_hjr = re.findall('<div class="onnum">(.+?)</div>',data)[0]
                year_hjr = year_hjr.encode('utf-8')
            except:year_hjr=''
            Inf_1 = day_hjr+' '+month_hjr+' '+year_hjr+'  هــ'.encode('utf-8')
            print Inf_1
            print '######################################################################'
            try:
                day_grgr = re.findall('<div class="thenameM">(.+?)</div>',data)[0]
                day_grgr = day_grgr.encode('utf-8')
            except:day_grgr=''
            try:
                month_grgr = re.findall('<div class="onnumM">(.+?)</div>',data)[0]
                month_grgr = month_grgr.encode('utf-8')
            except:month_grgr=''
            Inf_2 = day_grgr+' '+month_grgr
            print Inf_2
            print '######################################################################'
            try:
                Rst_hjr = re.findall('<td>اليوم منذ بداية السنة الهجرية</td>.+?<td>(.+?)	</td>',data,re.S)[0]
                Rst_hjr = 'اليوم منذ بداية السنة الهجرية'.encode('utf-8')+'  '+Rst_hjr
            except:Rst_hjr=''
            try:
                Dooa = re.findall('<h3>دعاء اليوم </h3>(.+?)</div>',data,re.S)[0]
                Dooa = Dooa.replace('\n','').replace('"','')
                Dooa =Dooa.encode('utf-8')
            except:Dooa=''
            self.get_Elyoum(Inf_1,Inf_2,Rst_hjr,Dooa)
        return Inf_1,Inf_2,Rst_hjr,Dooa
########################################جلب الراديو#############################################################
    def get_Radio(self):
        return "http://live.mp3quran.net:8006/"
    def get_RadioS(self):
        self.List_mp3RadioS = []
        data,token = '',''
        self.url = 'https://www.mp3quran.net/ar/ajax/radios'
        try:
            _Dat = St.get(self.url,timeout=10,verify=False).content
            token= re.findall('<meta name="csrf-token" content="(.+?)">',_Dat)[0]
        except:token=''
        self.Hdr = {'Host': 'www.mp3quran.net',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                    'Accept': 'application/json, text/plain, */*',
                    'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': token,
                    'Referer': 'https://www.mp3quran.net/ar/radios',
                    'Connection': 'keep-alive'}
        try:data = St.get(self.url,headers=self.Hdr,timeout=10,verify=False).json()
        except:data=''
        if data!='':
            for keys in data['radios']:
                name = keys['name'].encode('utf-8')
                urlt = keys['url']
                share_description = keys['share_description'].encode('utf-8')
                self.List_mp3RadioS.append(show_mp3quranAudio(name,urlt,'',share_description))
            return True,self.List_mp3RadioS
        else:
            self.List_mp3RadioS.append(show_mp3quranAudio('Probleme Connexion','','',''))
            return False,self.List_mp3RadioS
########################################جلب بيانات القارئ#############################################################
    def selectPlayer(self):
        defaultPlayer = 'systemplayer'
        serviceApp = False
        try:
            if os.path.exists('/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp'):
                from Plugins.SystemPlugins.ServiceApp.plugin import config_serviceapp
                if config_serviceapp.servicemp3.replace.value:
                    defaultPlayer = config_serviceapp.servicemp3.player.value
                else:
                    defaultPlayer = 'systemPlayer'
                serviceApp = True
            else:
                defaultPlayer = 'systemPlayer'
        except:
            defaultPlayer = 'systemPlayer'
        return (defaultPlayer, serviceApp)
    def get_player(self):
        rds = 4097
        defaultPlayer,serviceApp = self.selectPlayer()
        if serviceApp:
            if defaultPlayer == 'gstplayer':rds = 5001
            elif defaultPlayer == 'exteplayer3':rds = 5002
        return rds
########################################جلب بيانات الراديو#############################################################
    def get_InfosRadio(self):
        self.List_Radiomp3= []
        tree = ET.parse(PATH_Xml)
        for element in tree.iter('mp3'):
            name = element.find('name').text
            name = name.encode('utf-8')
            url = element.find('url').text
            self.List_Radiomp3.append(show_mp3quranAudio(name,url,'',''))
        return self.List_Radiomp3
########################################جلب بيانات الاستماع للقران 2#####################################################
    def get_koraa(self):
        self.List_suratmp3Koraa= []
        url = 'https://suratmp3.com/quran?top'
        try:self.data=St.get(url,timeout=10,verify=False).content
        except:self.data=''
        if self.data!='':
            blocks = self.data.split('<div class="table card-h _crds">')
            blocks.pop(0)
            for block in blocks:
                title =  re.findall('loading="lazy" alt="(.+?)"',block)[0].encode('utf-8')
                Img   =  re.findall('loading="lazy" alt=.+?src="(.+?)" />',block)[0]
                lnk   =  re.findall('<a class="title spf-link" href="(.+?)">',block)[0]
                Moshaf=  re.findall('<a class="novel".+?>.+?    				(.+?)    			</a>',block,re.S)[0].encode('utf-8')
                views =  re.findall('<span class="views">(.+?)</span>',block)[0].encode('utf-8')
                desc = Moshaf + '\n'+views+'  '+'عدد المشاهدات'.encode('utf-8')
                self.List_suratmp3Koraa.append(show_mp3quranAudio(title,lnk,Img,desc))
            return self.List_suratmp3Koraa
        else:
            self.List_mp3quran.append(show_mp3quran('للاسف مشكل في جلب البيانات','','',''))
            return self.List_suratmp3Koraa
    def get_koraaSourats(self,url,name,Img):
        self.List_koraaSourats= []
        self.Img = Img
        self.name= name
        try:self.data=St.get(url,verify=False).content
        except:self.data=''
        if self.data!='':
            blocks = self.data.split('<div class="bg-progress"></div>')
            blocks.pop(0)
            print len(blocks)
            for block in blocks:
                title =  re.findall('title-data="(.+?)"',block)[0].encode('utf-8')
                name1 = title+'  '+' بصوت '.encode('utf-8')+'  '+self.name.encode('utf-8')
                lnk   =  re.findall('sound-data="(.+?)"',block)[0]
                self.List_koraaSourats.append(show_mp3quranAudio(name1,lnk,self.Img,''))
            return True,self.List_koraaSourats
        else:
            self.List_koraaSourats.append(show_mp3quran('للاسف مشكل في جلب البيانات','','',''))
            return False,self.List_koraaSourats
########################################تحميل صور المقرئين#####################################################
    def get_NI(self,name):
        _Im,name1 = '',''
        name = name
        if 'i.ytimg.com' in name:
            name1=name.split('=')[-1]
            name1=name1[5:9]
        elif 'qurancomplex' in name:
            name0 = name.split('.')[-2]
            name2 = name0.split('/')[-5]
            name3 = name0.split('/')[-1]
            name1 = name2+name3
        else:
            name1 = name.split('.')[-2]
            name1 = name1.split('/')[-1]
        if ".jpg" in name:_Im = ".jpg"
        if ".jpeg" in name:_Im = ".jpeg"
        if ".png" in name:_Im = ".png"
        return str(name1)+"_"+_Im
    def Download_Img(self,url):
        import time
        _Im,picob,imgUrl = '','',''
        name = self.get_NI(url)
        imgUrl=url
        path = get_PathImg()+name
        self.filePath = path
        if 'i.ytimg.com' in imgUrl:
            picob = self['SorateYoutu']
            imgUrl=url.split('?sqp=')[0]
        elif 'qurancomplex' in imgUrl:
            picob = self['myPicAnsiteTassafoh']
            imgUrl=url
        else:
            picob = self['myPicAnsite']
            imgUrl=url
        if not fileExists(self.filePath):
            try:
                response = requests.get(imgUrl, stream=True,timeout=10,verify=False)
                with open(self.filePath, 'wb') as out_file:
                    shutil.copyfileobj(response.raw, out_file)
                del response#
				
                self.showPic_1(picobject=picob, picfile=self.filePath)
            except:pass
        else:
            self.showPic_1(picobject=picob, picfile=self.filePath)
		#self.showPic_1(picobject=self['myPicAnsite'], picfile=self.filePath)
    def showPic_1(self, picobject = None, picfile = None):#get_show_image
        from Components.AVSwitch import AVSwitch
        picobject.instance.setPixmap(gPixmapPtr())
        self.scale = AVSwitch().getFramebufferScale()
        self.picload = ePicLoad()
        size = picobject.instance.size()
        self.picload.setPara((size.width(),
            size.height(),
            self.scale[0],
            self.scale[0],
            False,
            1,
            '#80000000'))
        if enigmaos == 'oe2.0':
            value = self.picload.startDecode(picfile, 0, 0, False)
        else:
            value = self.picload.startDecode(picfile, False)
        if value == 0:
            ptr = self.picload.getData()
            if ptr != None:
                picobject.instance.setPixmap(ptr)
                picobject.show()
                del self.picload
        return
########################################جلب بيانات السور لـــ  MainMenu#####################################################
    def get_InfosSourat(self,inxd):
        T = ''
        self.url = 'https://equran.me/read-'+str(inxd)+'.html'
        try:self.data=St.get(self.url,headers=MyHead,verify=False).content
        except:self.data=''
        if self.data!='':
            blocks = self.data.split('<div class="infoSurat">')[1]
            blocks = blocks.split('<div class="clearfix"></div> </div> <div class="accessibility">')[0]
            rgx = '<i class="fas fa-circle-notch"></i> (.+?)</li>'
            _Dons = re.findall(rgx,blocks)
            for txt in _Dons:
                T +=txt.encode('utf-8')+'\n'
        return T
    def get_ChiFFrest(self,Chifr):
        self.TxT = Chifr
        self.TxT = self.TxT.split("السورة رقم")[1]
        self.TxT = self.TxT.split("المدة")[0]
        self.TxT = (self.TxT).replace(' ','').replace('\n','').replace('\r','').replace('\t','')
        print self.TxT[0:1],self.TxT[1:2],self.TxT[2:3]
        if self.TxT[0:2]=='00':return self.TxT[2:3]
        elif self.TxT[0:1]=='0' and self.TxT[1:2]!='0':return self.TxT[1:2]+self.TxT[2:3]
        else:return self.TxT
########################################جلب بيانات التأريخ#####################################################
    def get_TarikhHijri(self,day,month,year,Cnd):
        resultat,quet = '',''
        url,data = 'https://hijri.today/dateconversion.html',''
        if Cnd == 'gregorian':quet = {"day_gregorian": day,"month_gregorian": month,"year_gregorian": year,"gregorian": "1","convert": "تحويل"}
        else:quet = {"day_hijri":day,"month_hijri":month,"year_hijri":year,"hijri":"1","convert":"تحويل"}
        try:data=St.post(url,data=quet,timeout=10,verify=False).content
        except:data=''
        if data!='':
            rgx = '<h3> النتيجة : </h3> <p>(.+?)</p> </div> <div id="hijri_show">'
            try:
                resultat = re.findall(rgx,data)[0]
                resultat = resultat.encode('utf-8')
            except:resultat='معذرة مشكل في جلب البيانات'.encode('utf-8')
        else:resultat='معذرة مشكل في الاتصال بالمصدر'.encode('utf-8')
        return resultat
    def get_HijriNV(self,day,month,year):
        resultat = ''
        url = 'https://www.un-web.com/tools/date_converter_gregorian/'
        quet = {"dd": day,	"mm": month,"yyyy": year,"submit": ""}
        try:data=St.post(url,data=quet,verify=False).content
        except:data=''
        rgx = "<span class='result'> <span class='text-large'>(.+?) </span>"
        if data!='':
            try:resultat = re.findall(rgx,data)[0].encode('utf-8')
            except:resultat='...'
            if resultat!='...':
                Rslt = resultat.split('-')
                day   = Rslt[2]
                mount = Rslt[1]
                year = Rslt[0]
                return day,mount,year
            else:return '','',''
        else:return '','',''
    def clear_data2(self,data):
        data = data.replace('<br>','  ')
        data = data.replace('</h4><h5><strong>','\n')
        data = data.replace("<p><br>","\n")
        data = data.replace("<br>","\n")
        data = data.replace("<p>","\n")
        return data
    def get_HijriNV2(self,day,month,year,Cnd):
        data,blocks,quet = '','',''
        "https://mortb.com/%D8%AD%D8%B3%D8%A7%D8%A8-%D8%A7%D9%84%D8%B9%D9%85%D8%B1-%D8%A8%D8%A7%D9%84%D9%87%D8%AC%D8%B1%D9%8A-%D9%88%D8%A7%D9%84%D9%85%D9%8A%D9%84%D8%A7%D8%AF%D9%8A/"
        lnk = 'https://mortb.com/addons/date_cal/getmydate.php'
        if Cnd == 'gregorian':quet = {"day": day,"month": month,"year": year,"op": "ame","B1": "احسب","": ""}
        else:quet = {"day":day,"month": month,"year":year,"op":"ah","B1":"احسب","":""}
        try:
            data=St.post(lnk,headers=Headerso,data=quet,verify=False).content
            data = data.decode('utf-8')
        except:data=''
        if data!='':
            blocks = data.split('<h4>')[1]
            blocks = blocks.split('<br><strong>')[0]
            blocks = self.clear_data2(blocks)
        return blocks
########################################جلب قائمة الفيديوهات#####################################################
    def get_AnsiteYoutube(self):
        self.List_AnsiteYoutube = []
        import xml.etree.ElementTree as ET
        PATH_Xml = '/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/XML/YoutubVd/YoutubVd.xml'
        tree = ET.parse(PATH_Xml)
        for element in tree.iter('mp3'):
            url = element.find('url').text
            name = element.find('name').text
            name = name.encode('utf-8')
            self.List_AnsiteYoutube.append(show_mp3quranAudio(name,url,'',''))
####################################### جلب بيانات مجلد تحميل الصور #############################################
    def Get_Taille_Folder(self):
        Milef = get_PathImg()
        Milef = Milef.replace('imagesAnsite_1/','imagesAnsite_1')
        Tlle = get_Taille(Milef)
        Tlle = str(Tlle)
        return Tlle,Milef
####################################### مسح صور مجلد تحميل الصور #############################################
    def Clear_Folder_Img(self):
        Milef = get_PathImg()
        Milef = Milef.replace('imagesAnsite_1/','imagesAnsite_1')
        for root, dirs, files in os.walk(Milef):
            for f in files:
                os.unlink(os.path.join(root, f))
        return "OK"
####################################### اضافة فيديو لقائمة الفيديوهات YoutubVd.xml #############################################
    def Add_Video_xml_File(self,_id):
        self._id = _id
        Messg,Titl = '',''
        PATH_Xml = '/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/XML/YoutubVd/YoutubVd.xml'
        def replaces(filePath, text, subs, flags=0 ):
            with open( filePath, "r+" ) as file:
                fileContents = file.read()
                textPattern = re.compile( re.escape( text ), flags )
                fileContents = textPattern.sub( subs, fileContents )
                file.seek( 0 )
                file.truncate()
                file.write( fileContents )
            return 'OK','تمت العملية بنجاح مبارك عليك المشاهدة'+'\nعنوان الفيديو المضاف'+'\n'+Titl
        def get_title_vids(_id):
            Messg,Titl,data = '','',''
            video = "https://www.youtube.com/watch?v="+str(_id)
            tmx = '<meta name="title" content="(.+?)">'
            try:
                data = St.get(video,verify=False).content
            except:
                data = ''
            if data != '':
                try:
                    Titl = re.findall(tmx,data)[0]
                except:
                    Titl = ''
                if Titl != '' and 'description' not in Titl:
                    Messg = 'OK'
                    Titl = Titl
                else:
                    Messg = 'KO'
                    Titl  ='تعذر الوصول الى عنوان الرابط'
            else:
                Messg = 'KO'
                Titl  ='الظاهر أن الرابط غير صحيح'
            return Messg,Titl
        searchExp = '<stream>'
        A ='<stream>\n    <mp3>\n	    <name>'
        C ='</name>\n	    <url>'
        D ='</url>\n    </mp3>'
        Messg,Titl=get_title_vids(self._id)
        if Messg == 'KO':return 'KO',Titl.encode('utf-8')
        replaceExp= A+Titl.encode('utf-8')+C+str(self._id)+D
        Messg,Titl=replaces(PATH_Xml, searchExp, replaceExp, flags=0 )
        return Messg,Titl
####################################### اضافة فيديو لقائمة الفيديوهات YoutubVd.xml #############################################
    def Delt_Video_xml_File(self,_id):
        self._id = _id
        self.name,Messg= '','KO'
        Messg,Titl = '',''
        PATH_Xml = '/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/XML/YoutubVd/YoutubVd.xml'
        tree = ET.parse(PATH_Xml)
        root = tree.getroot()
        for mp3 in root.findall('mp3'):
            url = mp3.find('url').text
            if self._id in url:
                self.name= mp3.find('name').text
                root.remove(mp3)
                Messg= 'OK'
        if Messg == 'OK':
            tree.write(PATH_Xml, encoding="UTF-8")
            message = 'تمت العملية بنجاح'+'\nتم حذف'+'\n'+self.name
            return 'OK',message.encode('utf-8')
        else:return 'KO','معذرة لم يتم حذف المطلوب'
####################################### جلب تاريخ اليوم الميلادي #############################################
    def Get_Dates(self):
        import datetime
        date_youm = datetime.date.today()
        print(date_youm)
        return date_youm
####################################### جلب بيانات السور #############################################
    def get_InfosOratesQuran(self,indx):
        indx = int(indx)-1
        import xml.etree.ElementTree as ET
        T = ''
        MyPath = '/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/XML/InfosSourat.xml'
        MyListInfosOratesQuran = []
        tree = ET.parse(MyPath)
        for element in tree.iter('mp3'):
            name1 = element.find('name1').text
            name1 = name1.encode('utf-8')
            name2 = element.find('name2').text
            name2 = name2.encode('utf-8')
            name3 = element.find('name3').text
            name3 = name3.encode('utf-8')
            name4 = element.find('name4').text
            name4 = name4.encode('utf-8')
            name5 = element.find('name5').text
            name5 = name5.encode('utf-8')
            name6 = element.find('name6').text
            name6 = name6.encode('utf-8')
            name7 = element.find('name7').text
            name7 = name7.encode('utf-8')
            name8 = element.find('name8').text
            name8 = name8.encode('utf-8')
            MyListInfosOratesQuran.append((name1,name2,name3,name4,name5,name6,name7,name8))
        for t in range(8):
            T +=MyListInfosOratesQuran[indx][t]+'\n'
        return T
####################################### جلب بيانات السور تصفح القرآن الكريم #############################################
    def get_InfosTassafoh_Quran(self,Myfold):
        import xml.etree.ElementTree as ET
        T = ''
        MyPath = Myfold
        self.InfosTassafoh_Quran = []
        tree = ET.parse(MyPath)
        for element in tree.iter('mp3'):
            name = element.find('name').text
            url = element.find('url').text
            url = url.encode('utf-8')
            indx = url.split('/')[-1].split('.')[0]
            name = name.encode('utf-8')+'  الصفحة _'+'  '+str(int(indx)-3)
            page = element.find('page').text
            page = page.encode('utf-8')
            self.InfosTassafoh_Quran.append(show_mp3quranAudio(name,url,page,''))
        return self.InfosTassafoh_Quran
    def Write_Js(self,txt):
        path = '/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/Compmt/sourats.js'
        with open(path,'w') as chcfg:
            json.dump(txt, chcfg,ensure_ascii=False)
        print "OK"
    def Copy_Donnees(self,what):
        Milef = '/usr/lib/enigma2/python/Plugins/Extensions/Ansite/Adons/Compmt/folddons'
        if os.path.isfile(Milef):
            file_write = open(Milef, 'w')
            file_write.write(str(what))
            file_write.close()