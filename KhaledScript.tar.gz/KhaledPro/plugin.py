from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Tools.LoadPixmap import LoadPixmap
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
import os


def getIconPath():
    return "/usr/lib/enigma2/python/Plugins/Extensions/KhaledPro/icon.png"

class KhaledProPanel(Screen):
    # Professional FHD Skin
    skin = """
    <screen name="KhaledProPanel" position="center,center" size="900,600" title="Khaled Professional Panel v2.0">
        <widget name="menu" position="30,30" size="840,400" scrollbarMode="showOnDemand" font="Regular;30" itemHeight="55" />
        <ePixmap pixmap="buttons/red.png" position="50,520" size="35,35" alphatest="on" />
        <widget name="key_red" position="95,520" size="150,35" font="Regular;24" />
        <ePixmap pixmap="buttons/green.png" position="300,520" size="35,35" alphatest="on" />
        <widget name="key_green" position="345,520" size="200,35" font="Regular;24" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.setTitle("Khaled Professional Panel")
        
        # Mapping your script files to human-readable names
        self.script_folder = "/media/hdd/Script_New_Edition/TOOL/"
        self.scripts = [
            ("Update SoftCam (Auto-Restart)", "TOOL-Khaled_softcam_update.sh"),
            ("Install Professional Fonts", "TOOL-Khaledfonts.sh"),
            ("Restore Global Hotkeys", "TOOL-KhaledHotkey_all_image.sh"),
            ("Restore Global Settings", "TOOL-KhaledSettings_all_image.sh"),
            ("Bootlogo (OpenATV)", "TOOL-Bootlogo_ATV.sh"),
            ("Bootlogo (OpenPLi)", "TOOL-Bootlogo_PLI.sh"),
            ("Bootlogo (Pure2)", "TOOL-Bootlogo_PUR.sh"),
            ("Bootlogo (BlackHole)", "TOOL-Bootlogo_OBH.sh")
        ]
        
        self["menu"] = MenuList([x[0] for x in self.scripts])
        self["key_red"] = Label("Exit")
        self["key_green"] = Label("Run Selected")
        
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.runTool,
            "green": self.runTool,
            "red": self.close,
            "cancel": self.close
        }, -1)

    def runTool(self):
        idx = self["menu"].getSelectedIndex()
        if idx >= 0:
            name = self.scripts[idx][0]
            filename = self.scripts[idx][1]
            path = os.path.join(self.script_folder, filename)
            
            if os.path.exists(path):
                # Professional Background Console with visual logs
                self.session.openWithCallback(self.checkRestart, Console, title=name, cmdlist=[path])
            else:
                self.session.open(MessageBox, "Missing File: %s" % path, MessageBox.TYPE_ERROR)

    def checkRestart(self, result=None):
        # Some of your scripts use 'killall -9 enigma2' which will restart anyway
        # For others (like Settings), we ask if the user wants to reboot now
        pass

def main(session, **kwargs):
    session.open(KhaledProPanel)

def Plugins(**kwargs):
    return [PluginDescriptor(name="Khaled Pro Panel", description="The Professional Tool Suite", where=PluginDescriptor.WHERE_PLUGINMENU,icon=LoadPixmap(getIconPath()), fnc=main)]
