# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/Corvone/__init__.py
pass