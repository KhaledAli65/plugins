from twisted.internet import threads, task
from requests import Session
"""
session = AsyncSession()
d = session.get(url)
d.addCallback(cb_func)
d.addErrback(err_func)
"""

class AsyncSession(Session):

    def __init__(self, *args, **kwargs):
        super(AsyncSession, self).__init__(*args, **kwargs)

    def request(self, *args, **kwargs):
        func = super(AsyncSession, self).request
        return threads.deferToThread(func, *args, **kwargs)

    def run(self, f):
        return task.react(f)
