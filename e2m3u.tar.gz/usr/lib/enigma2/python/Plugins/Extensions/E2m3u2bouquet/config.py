# -*- coding:utf-8 -*-
import logging
from . import log
from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL

class E2m3u2bConfig(object):
    # ----------------------------------------------------
    # E2m3u2bouquet plugin configuration
    # ----------------------------------------------------
    #
    # Logging configuration
    # Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    loglevel = INFO
    # Log message format
    logfmt = '[%(asctime)s] [%(name)s] %(message)s'
    # Log date format
    logdatefmt = '%d.%m %H:%M:%S'
    # Files download timeout
    downloadTimeout = 120    # Valid value is an integer from 10 to 300


    # create logger
    logger = logging.getLogger('e2m3u2b')
    logger.setLevel(level=loglevel)
    # create formatter and add it to the handler
    formatter = logging.Formatter(fmt=logfmt, datefmt=logdatefmt)
    # create file handler for logger
    handler = logging.StreamHandler(log)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
