# -*- coding:utf-8 -*-
import os
from .. import PluginLanguageDomain, medialist
from ..log import logger
from . import epgdb


class EPGClass(object):

	services = []

	def __init__(self, epgfile):
		self.epg = epgdb.epgdb_class(PluginLanguageDomain, 99, epgfile)
		logger.debug("EPG database located at %s" % epgfile)

	def importEvents(self, services, events):
		'''
		This method is called repeatedly for each bit of data
                (starttime, duration, title, short_descr, long_descr, event_type, dvb_event_id, [(lang, parent_rating),])
                '''
		self.epg.events = events
		self.services = services
		self.commitService()

	def commitService(self):
		if self.services:
			self.epg.processServices(self.services)

	def epg_done(self):
		try:
			self.commitService()
		except Exception as err:
			logger.error("[epgdat_importer] failure in epg_done: %s" % err)
		finally:
			self.epg.final_process()
			self.epg = None

	def __del__(self):
		"""Destructor - finalize the file when done"""
		if self.epg is not None:
			self.epg_done()
