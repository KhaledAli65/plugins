from __future__ import division
from .. import _, getSkin, initTimer
from enigma import ePoint, eSize
from Components.Label import Label
from Screens.Screen import Screen
from ..config import E2m3u2bConfig
from collections import deque

logger = E2m3u2bConfig.logger

class Toast(Screen):
	DURATION_SHORT = 5
	DURATION_MEDIUM = 10
	DURATION_LONG = 30
	DURATION_VERY_LONG = 60

	def __init__(self, session, text, duration):
		Screen.__init__(self, session)
		self.skinName = 'E2m3u2b_Toast'
		self.skin = getSkin(self.skinName)
		self.duration = duration
		self["text"] = Label(text)
		self.onLayoutFinish.append(self._onLayoutFinish)

	def _onLayoutFinish(self):
		orgwidth = self.instance.size().width()
		orgpos = self.instance.position()
		textsize = self["text"].getSize()

		# y size still must be fixed in font stuff...
		textsize = (textsize[0] + 20, textsize[1] + 15)

		self.instance.resize(eSize(*textsize))
		self["text"].instance.resize(eSize(*textsize))

		# center window
		newwidth = textsize[0]
		self.instance.move(ePoint(orgpos.x() + (orgwidth - newwidth) // 2, orgpos.y()))

class ToastManager(object):
	def __init__(self, session):
		self._session = session
		self._queue = deque()
		self._deleteQueue = deque()
		self._currentToast = None
		self._toastTimer, self._toastTimer_conn = initTimer(self._onTimeout)

	def showToast(self, text, duration=Toast.DURATION_SHORT):
		screen = self._session.instantiateDialog(Toast, text, duration)
		self.show(screen)
		return screen

	def show(self, screen):
		self._queue.append(screen)
		self._processQueue()

	def hide(self, screen):
		if screen == self._currentToast:
			self._onTimeout()
		elif screen in self._queue:
			self._queue.remove(screen)
		else:
			logger.debug("Screen is not a toast or already about to be deleted %s" %(screen,))

	def _onTimeout(self):
		if self._currentToast:
			self._deleteQueue.append(self._currentToast)
			self._currentToast.hide()
			self._currentToast = None
		self._processQueue()

	def _processQueue(self):
		unfinished = deque()
		for toast in self._deleteQueue:
			unfinished.append(toast)
		self._deleteQueue = unfinished

		if self._currentToast or not self._queue:
			return
		self._currentToast = self._queue.popleft()
		self._currentToast.show()
		if hasattr(self._currentToast, "duration"):
			duration = self._currentToast.duration
		else:
			duration = Toast.DURATION_SHORT
		self._toastTimer.startLongTimer(duration)
