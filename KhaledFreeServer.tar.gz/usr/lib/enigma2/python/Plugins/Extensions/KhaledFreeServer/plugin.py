# -*- coding: utf-8 -*-
# DEVELOPED BY KHALED © 2026
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.Console import Console
import os

class KhaledFreeServerLauncher(Screen):
	# واجهة خفيفة وبسيطة جداً متوافقة مع جميع جودات الشاشات
	skin = """
	<screen name="KhaledFreeServerLauncher" position="center,center" size="750,260" title="Khaled Free Server" backgroundColor="#151515">
		<widget name="status_label" position="30,60" size="690,50" font="Regular;24" halign="center" valign="center" textColor="#ffffff" transparent="1" />
		<label text="DEVELOPED BY KHALED © 2026" position="30,130" size="690,40" font="Regular;18" halign="center" textColor="#00ff8000" transparent="1" />
		<widget name="key_red" position="50,190" size="200,45" backgroundColor="#ff0000" zPosition="1" transparent="0" font="Regular;20" halign="center" valign="center" textColor="#ffffff" />
		<widget name="key_green" position="500,190" size="200,45" backgroundColor="#00ff00" zPosition="1" transparent="0" font="Regular;20" halign="center" valign="center" textColor="#ffffff" />
	</screen>
	"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		
		self["status_label"] = Label("اضغط الزر الأخضر لتشغيل اسكريبت جلب السيرفرات")
		self["key_red"] = Label("خروج")
		self["key_green"] = Label("تشغيل الإسكريبت")
		
		self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
			"red": self.close,
			"green": self.run_sh_script,
			"cancel": self.close
		}, -2)

		# تحديد مسار السكريبت التلقائي بجانب ملف البايثون تماماً
		current_plugin_path = os.path.dirname(__file__)
		self.script_path = os.path.join(current_plugin_path, "Khaled_Free_Server.sh")

	def run_sh_script(self):
		if os.path.exists(self.script_path):
			# تنظيف ملف الشل من أسطر الويندوز الزائدة وإعطائه صلاحية التشغيل آلياً
			os.system("sed -i 's/\\r$//' %s" % self.script_path)
			os.system("chmod 755 %s" % self.script_path)
			
			# تشغيل السكريبت الصافي وعرض المخرجات مباشرة في كونسول الصورة
			cmd = "sh %s" % self.script_path
			self.session.open(Console, title="Khaled Free Server Live Bulk Process", cmdlist=[cmd])
		else:
			self["status_label"].setText("خطأ: لم يتم العثور على ملف Khaled_Free_Server.sh")

def main(session, **kwargs):
	session.open(KhaledFreeServerLauncher)

def Plugins(**kwargs):
	return [PluginDescriptor(
		name="Khaled Free Server",
		description="Launcher for Pure Levi Shell Engine",
		where=PluginDescriptor.WHERE_PLUGINMENU,
		icon="plugin.png",
		fnc=main
	)]

