#!/bin/sh
# DEVELOPED BY KHALED © 2026 - WGET BACKBONE ENGINE FOR UNIVERSAL COMPATIBILITY
LOG_FILE="/tmp/downloader.log"

# تحديد ملف الإنتاج آلياً بناءً على إعدادات الرسيفر أو افتراضياً لـ Ncam/Oscam
OUTPUT_FILE="/etc/tuxbox/config/ncam.server"
[ ! -f "$OUTPUT_FILE" ] && OUTPUT_FILE="/etc/tuxbox/config/oscam.server"

# القائمة الأساسية للروابط الثابتة
URLS=(
    "https://cccam-premium.pro/free-cccam/"
    "https://cccamsate.com/free"
    "https://cccamiptv.tv/cccamfree/#page-content"
    "https://cccam.net/freecccam"
    "https://cccamia.com/cccam-free/"
    "https://cccamhub.com/cccamfree/"
    "https://cccamgalaxy.com/"
    "https://cccamfree48h.yolasite.com/server-2.php"
    "https://raw.githubusercontent.com/levi-45/free-cccam/main/servers.txt"
)

# توليد روابط موقع testious الديناميكية لليوم والأمس عبر البايثون المدمج
YESTERDAY=$(python -c "from datetime import datetime, timedelta; print((datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d'))")
TODAY=$(python -c "from datetime import datetime; print(datetime.now().strftime('%Y-%m-%d'))")

URLS+=("https://testious.com/old-free-cccam-servers/$YESTERDAY/")
URLS+=("https://testious.com/old-free-cccam-servers/$TODAY/")

TEMP_FILE="/tmp/servers_temp.txt"
FINAL_FILE="/tmp/servers_final.txt"
CONVERTED_FILE="/tmp/servers_converted.txt"

> "$FINAL_FILE"
> "$TEMP_FILE"
> "$CONVERTED_FILE"

echo "=== Scraping Live Feeds (Wget Universal Engine) ==="

# دالة التفكيك والقنص الأصلية
parse_servers() {
    local content="$1"
    local clean_content=$(echo "$content" | sed 's/<[^>]*>//g' | tr -d '\r' | sed 's/&nbsp;/ /g' | sed 's/&amp;/\&/g')
    
    echo "$clean_content" | grep -oE 'C:[[:space:]]*[[:alnum:].-]+[[:space:]]+[0-9]+[[:space:]]+[[:alnum:].-]+[[:space:]]+[[:alnum:].-]+' >> "$TEMP_FILE"
    echo "$clean_content" | grep -oE 'C:[[:space:]]*[[:alnum:].-]+[[:space:]]+[0-9]+[[:space:]]+[[:alnum:].-]+[[:space:]]+[[:alnum:].-]+' | sed 's/$/ #/' >> "$TEMP_FILE"
    echo "$clean_content" | grep -oE 'N:[[:space:]]*[[:alnum:].-]+[[:space:]]+[0-9]+[[:space:]]+[[:alnum:].-]+[[:space:]]+[[:alnum:].-]+[[:space:]]+[0-9a-fA-F]+' >> "$TEMP_FILE"
}

# حلقة الجلب الاعتمادية باستخدام wget البديل الآمن لـ curl
for URL in "${URLS[@]}"; do
    echo "Downloading & Processing: $URL"
    
    # استخدام wget مع توقيت إغلاق 6 ثوانٍ وتخطي فحص الشهادات للحماية من التعليق
    if wget -q --no-check-certificate --timeout=6 --user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64)" "$URL" -O "$TEMP_FILE".download; then
        if [ -s "$TEMP_FILE".download ]; then
            CONTENT=$(cat "$TEMP_FILE".download)
            parse_servers "$CONTENT" "$URL"
        fi
        rm -f "$TEMP_FILE".download
    else
        echo "--> Timeout or Host Down: Skipping $URL safely..."
    fi
done

# تحويل الأسطر المجلوبة بكثافة إلى صيغة الريدرات (OSCam / NCam)
convert_to_oscam() {
    local line="$1"
    local parts=($line)
    if [ "${#parts[@]}" -lt 5 ]; then return; fi
    
    local protocol_type=$(echo "${parts[0]}" | tr -d ':')
    local host="${parts[1]}"
    local port="${parts[2]}"
    local user="${parts[3]}"
    local password="${parts[4]}"
    
    if [ "$protocol_type" = "C" ] || [ "$protocol_type" = "c" ]; then
        echo "[reader]"
        echo "label = ${host}_${port}"
        echo "protocol = cccam"
        echo "device = ${host},${port}"
        echo "user = ${user}"
        echo "password = ${password}"
        echo "group = 1"
        echo "cccversion = 2.1.2"
        echo "inactivitytimeout = 1"
        echo "reconnecttimeout = 30"
        echo "disablelog = 1"
        echo ""
    elif [ "$protocol_type" = "N" ] || [ "$protocol_type" = "n" ] && [ "${#parts[@]}" -ge 6 ]; then
        local key="${parts[5]}"
        echo "[reader]"
        echo "label = ${host}_${port}"
        echo "enable = 1"
        echo "protocol = newcamd"
        echo "key = ${key}"
        echo "device = ${host},${port}"
        echo "user = ${user}"
        echo "password = ${password}"
        echo "group = 1"
        echo "inactivitytimeout = 1"
        echo "reconnecttimeout = 30"
        echo "ccckeepalive = 1"
        echo ""
    fi
}

if [ -s "$TEMP_FILE" ]; then
    grep -E '^[CN]:' "$TEMP_FILE" | sed 's/#.*//' | sed 's/[[:space:]]*$//' | sort | uniq > "$FINAL_FILE"
    FINAL_COUNT=$(wc -l < "$FINAL_FILE")
    
    if [ "$FINAL_COUNT" -gt 0 ]; then
        START_MARKER="#--- KHALED FREE START ---"
        END_MARKER="#--- KHALED FREE END ---"
        
        while IFS= read -r line; do
            convert_to_oscam "$line" >> "$CONVERTED_FILE"
        done < "$FINAL_FILE"
        
        TARGET_CONFIGS=(
            "/etc/tuxbox/config/ncam.server"
            "/etc/tuxbox/config/oscam.server"
        )
        
        for config_path in "${TARGET_CONFIGS[@]}"; do
            if [ -f "$config_path" ]; then
                cp "$config_path" "${config_path}.bak"
                sed -i "/$START_MARKER/,/$END_MARKER/d" "$config_path"
                sed -i '/^$/N;/^\n$/D' "$config_path"
                echo "$START_MARKER" >> "$config_path"
                cat "$CONVERTED_FILE" >> "$config_path"
                echo "$END_MARKER" >> "$config_path"
            fi
        done
        echo "=== Sync Complete! Total Active Readers Installed: $FINAL_COUNT ==="
    fi
else
    echo "--> No servers found from any active source."
fi

rm -f "$TEMP_FILE" "$FINAL_FILE" "$CONVERTED_FILE" "$TEMP_FILE.download" 2>/dev/null

