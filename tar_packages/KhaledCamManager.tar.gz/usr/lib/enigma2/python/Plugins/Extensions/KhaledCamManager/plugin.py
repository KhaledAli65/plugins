# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigText, getConfigListEntry, ConfigSubsection
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
import os

# روابط الـ GitHub الخاصة بك لملفات الـ IPK والـ SoftCam
NCAM_URL = "https://github.com/KhaledAli65/emu/raw/refs/heads/main/enigma2-plugin-softcams-ncam.ipk"
OSCAM_URL = "https://github.com/KhaledAli65/emu/raw/refs/heads/main/enigma2-plugin-softcams-oscam-emu.ipk"
SOFTCAM_URL = "https://raw.githubusercontent.com/KhaledAli65/emu/refs/heads/main/SoftCam.Key"

# تحديد مسار مجلد البلجن الحالي تلقائياً لجلب صورة اللوجو
PLUGIN_PATH = resolveFilename(SCOPE_PLUGINS, "Extensions/KhaledCamManager")

# إعداد متغيرات تخزين السيرفر مؤقتاً في نظام الـ Config
config.plugins.khaledcam = ConfigSubsection()
config.plugins.khaledcam.host = ConfigText(default="example.com", fixed_size=False)
config.plugins.khaledcam.port = ConfigText(default="12000", fixed_size=False)
config.plugins.khaledcam.user = ConfigText(default="username", fixed_size=False)
config.plugins.khaledcam.password = ConfigText(default="password", fixed_size=False)

class KhaledCamManagerScreen(Screen):
    # سكين الواجهة الرئيسية بأبعاد مريحة وخطوط كبيرة جداً وواضحة
    skin = """
    <screen name="KhaledCamManagerScreen" position="center,center" size="900,580" title="Khaled Cam Manager V1.0">
        <widget name="logo" position="20,30" size="180,180" alphatest="on" />
        
        <widget name="menu" position="220,30" size="660,340" font="Regular;34" itemHeight="60" scrollbarMode="showOnDemand" />
        
        <widget name="status" position="20,460" size="860,100" font="Regular;30" halign="center" valign="center" foregroundColor="#00FF00" />
        
        <component type="Label" text="OK: اختر للتنفيذ | EXIT: خروج" position="20,410" size="860,40" font="Regular;24" halign="center" foregroundColor="#FFFFFF" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self["logo"] = Pixmap()
        
        # خيارات الواجهة الرئيسية
        self.list = [
            ("تثبيت ايمو انكام (Ncam IPK)", "install_ncam"),
            ("تثبيت ايمو اوسكام (Oscam IPK)", "install_oscam"),
            ("تحديث ملف السوفتكام (Softcam.key)", "install_softcam"),
            ("إدخال بيانات اشتراك السيسكام", "setup_cccam")
        ]
        
        self["menu"] = MenuList(self.list)
        self["status"] = Label("مرحباً بك في لوحة تحكم خالد للأيموهات")
        
        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.click_ok,
            "cancel": self.close
        }, -1)
        
        self.onLayoutFinish.append(self.show_logo)

    def show_logo(self):
        logo_file = os.path.join(PLUGIN_PATH, "logo.png")
        if os.path.exists(logo_file):
            self["logo"].instance.setPixmapFromFile(logo_file)

    def click_ok(self):
        returnValue = self["menu"].getCurrent()[1]
        if returnValue == "install_ncam":
            self.download_and_install_ipk(NCAM_URL, "Ncam")
        elif returnValue == "install_oscam":
            self.download_and_install_ipk(OSCAM_URL, "Oscam")
        elif returnValue == "install_softcam":
            self.download_softcam()
        elif returnValue == "setup_cccam":
            self.session.open(KhaledCCcamSetupScreen)

    # دالة الحذف والتحميل والتثبيت الإجباري الصارم الموحدة للكامات لتخطي عقبة نفس الإصدار
    def download_and_install_ipk(self, url, cam_name):
        self["status"].setText(f"جاري معالجة وتثبيت {cam_name}... يرجى الانتظار")
        
        # 1. تنظيف مسبق تام لمجلد الـ tmp
        os.system("rm -f /tmp/*.ipk")
        
        # 2. إيقاف الكام النشط أولاً وتنفيذ أمر الحذف الدقيق الذي طلبته لكل نسخة مسبقة
        if cam_name == "Ncam":
            os.system("killall -9 ncam 2>/dev/null")
            os.system("opkg remove enigma2-plugin-softcams-ncam 2>/dev/null")
            target_file = "/tmp/enigma2-plugin-softcams-ncam.ipk"
        else:
            os.system("killall -9 oscam 2>/dev/null")
            os.system("opkg remove enigma2-plugin-softcams-oscam-emu 2>/dev/null")
            target_file = "/tmp/enigma2-plugin-softcams-oscam-emu.ipk"
            
        # 3. التحميل المباشر للملف وحفظه باسمه الأصلي داخل الـ tmp
        download_cmd = f"wget --no-check-certificate '{url}' -O {target_file}"
        os.system(download_cmd)
        
        # 4. التحقق الفعلي من وجود الملف قبل التثبيت
        if os.path.exists(target_file):
            # تطبيق الأمر الموحد والصارم للإجبار على الحذف وإعادة التثبيت حتى لنفس الإصدار (للإنكام والأوسكام معاً)
            install_cmd = f"opkg update && opkg install --force-overwrite --force-reinstall --force-downgrade {target_file}"
            result = os.system(install_cmd)
            
            # تنظيف ملف الـ ipk بعد إتمام العملية
            os.system(f"rm -f {target_file}")
            
            if result == 0:
                self["status"].setText(f"تم بنجاح حذف الإصدار السابق وإعادة تثبيت {cam_name} بنجاح!")
            else:
                self["status"].setText(f"فشل التثبيت التلقائي لـ {cam_name}. قد يكون هناك تعارض في ملفات الصورة.")
        else:
            self["status"].setText(f"فشل تحميل ملف {cam_name} من السيرفر. تأكد من اتصال الإنترنت بجهازك.")

    def download_softcam(self):
        self["status"].setText("جاري تحديث ملف SoftCam.Key من السيرفر...")
        paths = ["/etc/tuxbox/config/SoftCam.Key", "/usr/keys/SoftCam.Key", "/etc/tuxbox/config/ncam.key", "/etc/tuxbox/config/oscam.key"]
        
        cmd = f"wget --no-check-certificate -q '{SOFTCAM_URL}' -O /tmp/SoftCam.Key"
        result = os.system(cmd)
        
        if result == 0 and os.path.exists("/tmp/SoftCam.Key"):
            for path in paths:
                os.system(f"cp /tmp/SoftCam.Key {path} 2>/dev/null")
            os.system("rm -f /tmp/SoftCam.Key")
            self["status"].setText("تم تحديث ملف SoftCam.Key بنجاح في كافة مسارات الإيموهات!")
        else:
            self["status"].setText("فشل في جلب ملف السوفتكام من الروابط.")


# واجهة تعديل وإدخال بيانات السيرفر (صفوف كبيرة الحجم متوافقة مع الريموت والكيبورد)
class KhaledCCcamSetupScreen(ConfigListScreen, Screen):
    skin = """
    <screen name="KhaledCCcamSetupScreen" position="center,center" size="850,520" title="إعدادات سيرفر سيسكام - لوحة خالد">
        <widget name="config" position="20,20" size="810,320" font="Regular;30" itemHeight="60" scrollbarMode="showOnDemand" />
        
        <ePixmap pixmap="skin_default/buttons/green.png" position="40,380" size="240,50" alphatest="on" />
        <ePixmap pixmap="skin_default/buttons/red.png" position="570,380" size="240,50" alphatest="on" />
        <widget name="key_green" position="40,380" size="240,50" zPosition="1" font="Regular;26" halign="center" valign="center" backgroundColor="#00FF00" transparent="1" />
        <widget name="key_red" position="570,380" size="240,50" zPosition="1" font="Regular;26" halign="center" valign="center" backgroundColor="#FF0000" transparent="1" />
        
        <widget name="hint" position="20,450" size="810,60" font="Regular;22" halign="center" valign="center" foregroundColor="#FFFF00" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        self.list = [
            getConfigListEntry("الهوست (Host / IP):", config.plugins.khaledcam.host),
            getConfigListEntry("المنفذ (Port):", config.plugins.khaledcam.port),
            getConfigListEntry("اسم المستخدم (User):", config.plugins.khaledcam.user),
            getConfigListEntry("كلمة المرور (Password):", config.plugins.khaledcam.password)
        ]
        
        ConfigListScreen.__init__(self, self.list, session=self.session)
        
        self["key_green"] = Label("حفظ البيانات")
        self["key_red"] = Label("إلغاء وخروج")
        self["hint"] = Label("اضغط OK على أي حقل لفتح الكيبورد الافتراضي للصورة والكتابة بسلاسة")
        
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"], {
            "green": self.save_data,
            "red": self.close,
            "ok": self.open_keyboard,
            "cancel": self.close
        }, -1)

    def open_keyboard(self):
        current_entry = self["config"].getCurrent()
        if current_entry:
            config_object = current_entry[1]
            self.session.openWithCallback(self.keyboard_callback, VirtualKeyBoard, title=current_entry[0], text=config_object.value)

    def keyboard_callback(self, callback_text):
        if callback_text is not None:
            self["config"].getCurrent()[1].setValue(callback_text)
            self["config"].invalidate(self["config"].getCurrent())

    def save_data(self):
        host = config.plugins.khaledcam.host.value
        port = config.plugins.khaledcam.port.value
        user = config.plugins.khaledcam.user.value
        password = config.plugins.khaledcam.password.value
        
        reader_data = (
            "\n[reader]\n"
            "label = Khaled_CCcam_Server\n"
            "protocol = cccam\n"
            f"device = {host},{port}\n"
            f"user = {user}\n"
            f"password = {password}\n"
            "inactivitytimeout = 30\n"
            "group = 1\n"
            "cccversion = 2.3.2\n"
            "ccckeepalive = 1\n"
        )
        
        server_files = [
            "/etc/tuxbox/config/ncam.server",
            "/etc/tuxbox/config/oscam.server",
            "/etc/tuxbox/config/ncam/ncam.server",
            "/etc/tuxbox/config/oscam/oscam.server"
        ]
        
        success_count = 0
        for file_path in server_files:
            if os.path.exists(os.path.dirname(file_path)):
                try:
                    with open(file_path, "a+") as f:
                        f.write(reader_data)
                    success_count += 1
                except:
                    pass
                    
        os.system("killall -9 ncam oscam 2>/dev/null")
        self.close()

def Main(session, **kwargs):
    session.open(KhaledCamManagerScreen)

def Plugins(**kwargs):
    return PluginDescriptor(
        name="Khaled Cam Manager",
        description="تثبيت ايموهات انكام، اوسكام، سوفتكام وإدارة اشتراكات CCcam",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="plugin.png",
        fnc=Main
    )

