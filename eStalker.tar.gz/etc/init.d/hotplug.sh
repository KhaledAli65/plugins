#!/bin/sh

mdev -s &
exit 0
