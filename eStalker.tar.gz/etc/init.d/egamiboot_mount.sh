orgimag=`mount | sed '/sd/!d' | cut -d" " -f1`
rm -f /media/egamiboot/EgamiBootI/openbh-5.5.1.011-novaler4kse/usr/bin/enigma2_pre_start.sh
for item in $orgimag; do
	ohdd=`echo  $item | cut -d"/" -f3` 
	nhdd=`mount | sed "/$ohdd/!d" | sed q | cut -d" " -f3`
	if [ $nhdd == '/media/egamiboot' ]; then
		echo "mkdir "$nhdd  >> /media/egamiboot/EgamiBootI/openbh-5.5.1.011-novaler4kse/usr/bin/enigma2_pre_start.sh
		echo "mount "$item $nhdd  >> /media/egamiboot/EgamiBootI/openbh-5.5.1.011-novaler4kse/usr/bin/enigma2_pre_start.sh 
	else
		echo "umount "$nhdd  >> /media/egamiboot/EgamiBootI/openbh-5.5.1.011-novaler4kse/usr/bin/enigma2_pre_start.sh
		echo "mkdir "$nhdd  >> /media/egamiboot/EgamiBootI/openbh-5.5.1.011-novaler4kse/usr/bin/enigma2_pre_start.sh
		echo "mount "$item $nhdd  >> /media/egamiboot/EgamiBootI/openbh-5.5.1.011-novaler4kse/usr/bin/enigma2_pre_start.sh
	fi
done
chmod 755 /media/egamiboot/EgamiBootI/openbh-5.5.1.011-novaler4kse/usr/bin/enigma2_pre_start.sh
