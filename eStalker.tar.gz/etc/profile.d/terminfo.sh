export TERMINFO=/etc/terminfo
export TERM=xterm-color
