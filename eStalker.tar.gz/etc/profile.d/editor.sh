export EDITOR="/bin/editor"
