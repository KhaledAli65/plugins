# 2017.01.31 12:23:11 Jerusalem Standard Time
#Embedded file name: /usr/lib/enigma2/python/Plugins/TSimage/TSimagePanel/Stools/TSsatEditor/ServiceEditor/__init__.py
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from os import environ as os_environ
import gettext

def localeInit():
    lang = language.getLanguage()[:2]
    os_environ['LANGUAGE'] = lang
    gettext.bindtextdomain('ServiceEditor', resolveFilename(SCOPE_PLUGINS, 'SystemPlugins/ServiceEditor/po/'))


def _(txt):
    t = gettext.dgettext('ServiceEditor', txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


localeInit()
language.addCallback(localeInit)
# okay decompyling G:\TSpanel\7.8\6\tsimageopentsimage\TSimage\TSimagePanel\Stools\TSsatEditor\ServiceEditor\__init__.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2017.01.31 12:23:11 Jerusalem Standard Time
