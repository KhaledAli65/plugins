#Embedded file name: /usr/lib/enigma2/python/Plugins/TSimage/TSimagePanel/__init__.py
pass
