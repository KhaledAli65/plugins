#-*- coding: utf-8 -*-
SITE_IDENTIFIER = 'Enregistrement'
SITE_NAME = 'enregistrement'

class cEnregistremement:
    def programmation_enregistrement(self, sUrl):
        pass

def GetTimeObject(durer, formats):
    return 0
