# -*- coding: utf-8 -*-
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG
from Plugins.Extensions.IPTVPlayer.tsiplayer.libs.tstools import TSCBaseHostClass,tshost
import re

def getinfo():
    info_={}
    name = 'TukTukCinema'
    hst = 'https://w.tuktukcinema.net'
    info_['old_host'] = hst
    hst_              = tshost(name)	
    if hst_!='': hst  = hst_
    info_['host']     = hst
    info_['name']     = name
    info_['version']  = '2.0 18/07/2022'
    info_['dev']      = 'RGYSoft'
    info_['cat_id']   = '21'
    info_['desc']     = 'هنا معلومات عن الموقع'
    info_['icon']     = hst+'/wp-content/uploads/2021/01/lela.png'
    return info_
   
class TSIPHost(TSCBaseHostClass):
    def __init__(self):
        TSCBaseHostClass.__init__(self,{})
        self.MAIN_URL      = getinfo()['host']
              
    def showmenu(self,cItem):
        TAB = [('افلام','','10',0),('مسلسلات','','10',1),('انميات','','10',2),('برامج تلفزيونية','','10',3)]
        printDBG('showmenu')
        self.add_menu(cItem,'','','','','',TAB=TAB,search=True)        

    def showmenu1(self,cItem):
        printDBG('showmenu1')
        self.add_menu(cItem,'<ul class="sub-menu">(.*?)</ul>','<li.*?href="(.*?)".*?>(.*?)<','','20',ind_0=cItem.get('sub_mode',0),ord=[0,1])
        
    def showitms(self,cItem):
        desc = [('Genre','class="Genres">(.*?)</ul>','','')]
        next = ['class="next.page-numbers".href="(.*?)"','20']
        self.add_menu(cItem,'','class="Block--Item">.*?href="(.*?)".*?data-src="(.*?)"(.*?)<h3>(.*?)</h3>','','21',ord=[0,3,1,2],Desc=desc,Next=next,u_titre=True,EPG=True)		

    def showelms(self,cItem):
        sts, data = self.getPage(cItem.get('url',''))
        if sts:
            if '/watch/' in data: 
                self.addVideo({'category':'host2','good_for_fav':True, 'title':cItem['title'],'url':cItem['url'], 'desc':cItem.get('desc',''),'import':cItem['import'],'icon':cItem['icon'],'hst':'tshost'})						
            self.add_menu(cItem,'<section class="allepcont(.*?)</section>','<a href="(.*?)".*?alt="(.*?)".*?data-src="(.*?)"',data,'video',ord=[0,1,2],Titre='الحلقات',u_titre=True,EPG=True,add_vid=False)		
            self.add_menu(cItem,'<section class="allseasonss"(.*?)</section>','Block--Item">.*?href="(.*?)".*?alt="(.*?)".*?data-srccs="(.*?)"',data,'21',ord=[0,1,2],Titre='المواسم',u_titre=True,EPG=True,add_vid=False)		
       
    def get_links(self,cItem): 	
        urlTab = []	
        URL=cItem['url']
        if not URL.endswith('/watch/'):
            if not URL.endswith('/'): URL = URL+'/watch/'
            else: URL = URL+'watch/'
        sts, data = self.getPage(URL)
        if sts:
            Liste_els = re.findall('<li data-link="(.*?)".*?>(.*?)</li>', data, re.S)
            for (url,titre) in Liste_els:
                titre = self.cleanHtmlStr(titre)
                url = url+'|Referer='+URL
                urlTab.append({'name':titre, 'url':url, 'need_resolve':1})	
        return urlTab


    def getArticle(self,cItem):
        Desc = [('Genre','catssection">(.*?)</div','',''),('Story','<p>(.*?)</p>','\n','')]
        desc = self.add_menu(cItem,'','class="story">(.*?)</article>','','desc',Desc=Desc)	
        if desc =='': desc = cItem.get('desc','')
        return [{'title':cItem['title'], 'text': desc, 'images':[{'title':'', 'url':cItem.get('icon','')}], 'other_info':{}}]


    def SearchResult(self,str_ch,page,extra):
        url=self.MAIN_URL+'/?s='+str_ch+'&page='+str(page)
        desc = [('Genre','class="Genres">(.*?)</ul>','','')]
        self.add_menu({'import':extra,'url':url},'','class="Block--Item">.*?href="(.*?)".*?title="(.*?)".*?img src="(.*?)"(.*?)</a>','','21',ord=[0,1,2,3],Desc=desc,u_titre=True,EPG=True)		