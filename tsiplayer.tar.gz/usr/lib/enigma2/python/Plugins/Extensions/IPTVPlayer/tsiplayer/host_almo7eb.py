# -*- coding: utf-8 -*-
from Plugins.Extensions.IPTVPlayer.libs import ph
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG
from Plugins.Extensions.IPTVPlayer.tsiplayer.libs.tstools import TSCBaseHostClass,tscolor,tshost,gethostname
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes             import strwithmeta

import re,urllib
import base64



def getinfo():
    info_={}
    name = 'Almo7eb'
    hst = 'https://www.almo7eb.com'
    info_['old_host'] = hst
    hst_ = tshost(name)	
    if hst_!='': hst = hst_
    info_['host']= hst
    info_['name']=name
    info_['version']='1.0 18/07/2022'    
    info_['dev']='RGYSoft'
    info_['cat_id']='21'
    info_['desc']='Almo7eb Films'
    info_['icon']='https://i.ibb.co/wQ0FX88/almo7eb.png'
    info_['recherche_all']='1'
    info_['update']='New Site'
    return info_
    
    
class TSIPHost(TSCBaseHostClass):
    def __init__(self):
        TSCBaseHostClass.__init__(self,{'cookie':'aflamfree.cookie'})
        self.MAIN_URL = getinfo()['host']

    def showmenu(self,cItem):
        TAB = [('Main','/ar/','10',0),('الافلام','/ar/m7b-273','20',1),('المسلسلات','/ar/m7b-525','20',2),]
        self.add_menu(cItem,'','','','','',TAB=TAB,search=True)

    def showmenu1(self,cItem):
        gnr = cItem.get('sub_mode',0)
        sts, data = self.getPage(cItem['url'])
        data_list = re.findall('id=\'blocktitle\'>(.*?)</h3>(.*?)(?:<h3|id=\'pagination)', data, re.S)
        for (titre,data_) in data_list:
            self.addDir({'import':cItem['import'],'category' : 'host2','url': cItem['url'],'title':self.cleanHtmlStr(titre),'desc':'','icon':cItem['icon'],'mode':'20','data':data_})
                  
    def showitms(self,cItem):
        data  = cItem.get('data','')
        sts   = True
        next_ = False
        if data=='':
            page = cItem.get('page',1)
            url0 = cItem['url']+ '&page='+str(page)+'.html'
            next_ = True
            sts, data = self.getPage(url0)
        if sts:
            data_list = re.findall('<a href=\'(.*?)\'.*?src=\'(.*?)\'.*?title=\'(.*?)\'', data, re.S)
            for (url,image,titre) in data_list:
                if not (url.endswith('/ar') or url.endswith('.com')):
                    image = self.MAIN_URL + '/ar/' + image
                    if '?url=' in url: x1,url = url.split('?url=',1)
                    printDBG('url====='+url)
                    self.addDir({'import':cItem['import'],'category' : 'host2','url': url,'title':titre,'desc':'','icon':image,'mode':'21','good_for_fav':True})            
        if next_:
            self.addDir({'import':cItem['import'],'category' : 'host2','url': cItem['url'],'title':'Next Page','desc':'','icon':cItem['icon'],'mode':'20','page':page+1})  
    
    def showelms(self,cItem):
        sts, data = self.getPage(cItem['url']) 
        if sts:
            data_list = re.findall('<a data-id=\'(.*?)\'.*?data-name=\'(.*?)\'.*?data-post=\'(.*?)\'', data, re.S)
            if data_list:
                for (id_,titre,post_) in data_list:
                    url_post = self.MAIN_URL + '/ar/serv.php'
                    url = url_post+'%%%'+id_+'%%%'+titre+'%%%'+post_
                    self.addVideo({'import':cItem['import'],'good_for_fav':True,'category':'host2', 'url':url, 'desc':cItem['desc'],'title':titre, 'icon':cItem['icon'],'EPG':True,'hst':'tshost'} )
            else:
                data_list = re.findall('class="button-stream".*?href="(.*?)".*?>(.*?)<', data, re.S)
                for (url,titre) in data_list:
                    self.addVideo({'import':cItem['import'],'good_for_fav':True,'category':'host2', 'url':url, 'desc':cItem['desc'],'title':titre, 'icon':cItem['icon'],'EPG':True,'hst':'tshost'} )

    def get_links(self,cItem): 	
        urlTab = []	
        URL    = cItem['url']				
        printDBG('URL===='+str(URL))
        if '%%%' in URL:
            url_post,id_,titre,post_ = URL.split('%%%')
            printDBG('Params===='+str((id_,titre,post_)))
            post_data = {'vid':id_,'name':titre,'post':post_}
            sts, data = self.getPage(url_post,post_data=post_data)
            if sts:
                elms_data = re.findall('id=\'(?:playserver|playphoto|playyoutube|playdrive|playlinkbox)\'.*?data-code=\'(.*?)\'.*?data-thefile=\'(.*?)\'', data, re.S)
                i=1
                for (code,url1) in elms_data:
                    MainURL = self.MAIN_URL + '/ar/'
                    url0 = 'hst#tshost#'+code+'|||'+url1+'|||'+MainURL
                    urlTab.append({'name':'Server '+str(i), 'url':url0, 'need_resolve':1})
                    i=i+1                         
        else:
            sts, data = self.getPage(URL)
            if sts:
                elms_data = re.findall('playerbuttn\'.*?href=\'(.*?)\'', data, re.S)
                i=1
                for (url) in elms_data:
                    url0 = 'hst#tshost#'+URL+url
                    urlTab.append({'name':'Server '+str(i), 'url':url0, 'need_resolve':1})
                    i=i+1 
        return urlTab
        
    def getVideos(self,videoUrl):
        urlTab = []	
        if '|||' in videoUrl:
            code_,url_,MainURL = videoUrl.split('|||')
            post_data = {'code':code_}
            url_post = MainURL  + url_
            sts, data = self.getPage(url_post,post_data=post_data)
            printDBG('Data====='+data)
        else:
            sts, data = self.getPage(videoUrl)
        if sts:
            elms_data = re.findall('<source src=\'(.*?)\'.*?label=\'(.*?)\'', data, re.S)        
            if elms_data:
                for (url,label) in elms_data:
                    if 'googlevideo' in url:
                        url = strwithmeta(label+'|'+url.strip(),{'User-Agent': self.USER_AGENT})
                    else:
                        url = strwithmeta(label+'|'+url.strip(),{'Referer':'https://shahed.life/','User-Agent': self.USER_AGENT})
                    urlTab.append((url,'4'))
            else:
                elms_data = re.findall('<iframe.*?src=[\'"](.*?)[\'"]', data, re.S)        
                if elms_data:
                    url = elms_data[0]
                    if url.startswith('//'): url = 'https:'+url
                    url = strwithmeta(url,{'User-Agent': self.USER_AGENT})
                    urlTab.append((url,'1'))
        return urlTab
        
    def SearchResult(self,str_ch,page,extra):
        elms = []
        url0 = self.MAIN_URL+'/ar/search.php?q='+str_ch+'&sitesearch=almo7eb&page='+str(page)
        sts, data = self.getPage(url0)
        if sts:
            data_list = re.findall('class=\'article\'>.*?image: url\((.*?)\).*?<a href=\'(.*?)\'.*?>(.*?)<', data, re.S)
            for (image,url,titre) in data_list:
                if '?url=' in url: x1,url = url.split('?url=',1)
                printDBG('url====='+url)
                self.addDir({'import':extra,'category' : 'host2','url': url,'title':titre,'desc':'','icon':image,'mode':'21','good_for_fav':True})            
